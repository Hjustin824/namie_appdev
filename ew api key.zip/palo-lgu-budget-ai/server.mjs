// Shared backend for LGU Palo Budget Monitoring System.
// Zero dependencies — plain Node.js http server + JSON file database.
//
// Why this exists: the app previously stored everything in each browser's
// localStorage, so a viewer on one phone/PC could never reach the admin on
// another device. This server holds ONE shared database (server-data.json)
// so viewer feedback sent from any device appears in the admin inbox.
//
// Run:  npm run server   (serves API + production build on http://localhost:3001)
// Dev:  npm run dev      (vite on :5173 proxies /api -> :3001, so run both)
// Phones on the same WiFi: http://<your-laptop-ip>:3001

import http from 'node:http';
import { readFile, writeFile, stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3001);
const DATA_FILE = path.join(__dirname, 'server-data.json');
const DIST_DIR = path.join(__dirname, 'dist');

function defaultDb() {
  return {
    accounts: [],
    activities: [],
    vendors: [],
    vouchers: [],
    billings: [],
    feedbacks: [],
    events: [],
    fiscalYear: new Date().getFullYear(),
  };
}

async function readDb() {
  try {
    if (!existsSync(DATA_FILE)) {
      const db = defaultDb();
      await writeFile(DATA_FILE, JSON.stringify(db, null, 2));
      return db;
    }
    const raw = await readFile(DATA_FILE, 'utf8');
    const db = { ...defaultDb(), ...JSON.parse(raw) };
    if (!Array.isArray(db.feedbacks)) db.feedbacks = [];
    if (!Array.isArray(db.events)) db.events = [];
    for (const k of ['accounts', 'activities', 'vendors', 'vouchers', 'billings']) {
      if (!Array.isArray(db[k])) db[k] = [];
    }
    return db;
  } catch {
    return defaultDb();
  }
}

async function writeDb(db) {
  await writeFile(DATA_FILE, JSON.stringify(db, null, 2));
}

/** Merge feedback lists by id so concurrent viewer + admin writes never lose data. */
function mergeFeedbacks(serverFbs, incomingFbs) {
  const byId = new Map();
  for (const f of serverFbs) byId.set(f.id, f);
  for (const f of incomingFbs || []) byId.set(f.id, f);
  return [...byId.values()].sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
}

function sendJson(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(body);
}

function readBody(req, limit = 5 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(new Error('Body too large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      try {
        resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {});
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

async function serveStatic(req, res) {
  try {
    let urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname);
    if (urlPath === '/') urlPath = '/index.html';
    const file = path.normalize(path.join(DIST_DIR, urlPath));
    if (!file.startsWith(DIST_DIR)) {
      res.writeHead(403);
      res.end('Forbidden');
      return true;
    }
    try {
      await stat(file);
    } catch {
      // SPA fallback
      const index = path.join(DIST_DIR, 'index.html');
      if (existsSync(index)) {
        const html = await readFile(index);
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(html);
        return true;
      }
      return false;
    }
    const ext = path.extname(file).toLowerCase();
    const data = await readFile(file);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
    return true;
  } catch {
    return false;
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (req.method === 'OPTIONS') {
      sendJson(res, 204, {});
      return;
    }

    // --- API ---
    if (url.pathname === '/api/health') {
      sendJson(res, 200, { ok: true, time: new Date().toISOString() });
      return;
    }
    if (url.pathname === '/api/state' && req.method === 'GET') {
      sendJson(res, 200, await readDb());
      return;
    }
    if (url.pathname === '/api/state' && req.method === 'PUT') {
      const incoming = await readBody(req);
      const current = await readDb();
      const next = {
        accounts: Array.isArray(incoming.accounts) ? incoming.accounts : current.accounts,
        activities: Array.isArray(incoming.activities) ? incoming.activities : current.activities,
        vendors: Array.isArray(incoming.vendors) ? incoming.vendors : current.vendors,
        vouchers: Array.isArray(incoming.vouchers) ? incoming.vouchers : current.vouchers,
        billings: Array.isArray(incoming.billings) ? incoming.billings : current.billings,
        feedbacks: mergeFeedbacks(current.feedbacks, incoming.feedbacks),
        events: Array.isArray(incoming.events) ? incoming.events : (current.events || []),
        fiscalYear: Number(incoming.fiscalYear) || current.fiscalYear,
      };
      await writeDb(next);
      sendJson(res, 200, next);
      return;
    }
    if (url.pathname === '/api/feedbacks' && req.method === 'GET') {
      const db = await readDb();
      sendJson(res, 200, db.feedbacks);
      return;
    }
    if (url.pathname === '/api/feedbacks' && req.method === 'POST') {
      const fb = await readBody(req);
      if (!fb || !fb.id || !fb.subject || !fb.message) {
        sendJson(res, 400, { error: 'id, subject and message are required' });
        return;
      }
      const db = await readDb();
      if (!db.feedbacks.some((f) => f.id === fb.id)) db.feedbacks.unshift(fb);
      await writeDb(db);
      sendJson(res, 201, fb);
      return;
    }
    const m = url.pathname.match(/^\/api\/feedbacks\/(.+)$/);
    if (m) {
      const id = decodeURIComponent(m[1]);
      const db = await readDb();
      const idx = db.feedbacks.findIndex((f) => f.id === id);
      if (req.method === 'PATCH') {
        if (idx === -1) {
          sendJson(res, 404, { error: 'Not found' });
          return;
        }
        const patch = await readBody(req);
        if (patch.status !== undefined) db.feedbacks[idx].status = patch.status;
        if (patch.response !== undefined) db.feedbacks[idx].response = patch.response;
        await writeDb(db);
        sendJson(res, 200, db.feedbacks[idx]);
        return;
      }
      if (req.method === 'DELETE') {
        db.feedbacks = db.feedbacks.filter((f) => f.id !== id);
        await writeDb(db);
        sendJson(res, 200, { ok: true });
        return;
      }
    }

    // --- Static (production build) ---
    if (existsSync(DIST_DIR)) {
      const handled = await serveStatic(req, res);
      if (handled) return;
    } else if (!url.pathname.startsWith('/api/')) {
      sendJson(res, 200, {
        ok: true,
        api: true,
        hint: 'Frontend not built yet (no dist/). Run: npm run build, then open this URL again. API is live at /api/state.',
      });
      return;
    }

    sendJson(res, 404, { error: 'Not found' });
  } catch (err) {
    sendJson(res, 500, { error: String(err?.message || err) });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  LGU Palo shared server running:`);
  console.log(`  - This PC:  http://localhost:${PORT}`);
  console.log(`  - Phones/PCs on same WiFi: http://<this-PC-IP>:${PORT}`);
  console.log(`  - API health: http://localhost:${PORT}/api/health`);
  console.log(`  - Database file: server-data.json\n`);
});
