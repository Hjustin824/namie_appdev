@echo off
cd /d C:\Users\Justin\palo-lgu-budget-ai
npm start
pause
