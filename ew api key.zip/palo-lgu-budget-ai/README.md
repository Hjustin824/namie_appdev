# LGU Palo, Leyte — AI-Driven Budget Monitoring System

React + TypeScript + Vite. Vendor forecasting algorithm included.

## Offices covered
- Palo Technical Vocational School (TVS)
- Municipal Health Office (MHO)
- Mayor's Office (MAYOR)

## Roles & permissions
| Capability | 🔐 Admin | 👁️ Viewer/User |
|---|---|---|
| View dashboard (read-only summary) | ✅ | ✅ |
| View bank, budget, vendors, vouchers, reports, forecast | ✅ | ❌ (dashboard only) |
| Add / edit / delete bank accounts, budgets, vendors, vouchers, billings | ✅ | ❌ |
| Verify bank balances, approve/release vouchers | ✅ | ❌ |
| Send feedback, comments, suggestions, concerns | ❌ (inbox only) | ✅ |
| Review, respond to, resolve & delete feedback | ✅ (Feedback inbox) | ❌ (sees own + admin responses) |

- **Login:** viewer enters any name; admin logs in with username `admin` + password (default `admin123`, changeable in the sidebar).
- **Empty start:** the system ships with no fixed numbers or business data. The admin encodes everything through the UI forms; each section shows guided empty states until data exists.

## Features
1. **Dashboard** — bank totals, FY approved/obligated, utilization %, payables, monthly billings, top AI forecasts (all computed live)
2. **Bank Verification** — add/edit/delete accounts, ledger vs bank statement, variance detection, verify workflow
3. **Annual Budget Planner** — add/edit/delete/approve activities & projects per office per fiscal year
4. **Vendor Management** — register/edit/deactivate/remove businesses, search/filter, lifetime billed + AI forecast per vendor
5. **Voucher Generator** — add/edit/delete disbursement vouchers, LGU-PALO-YYYY-XXXXXX auto-numbering, Pending→Approved→Released pipeline, printable voucher
6. **Billing Reports** — monthly & annual reports plus a billing-records encoder (add/edit/delete); every record flows automatically into reports, dashboard and forecast; CSV export, print
7. **AI Forecasting Engine** — hybrid OLS linear trend + 3-mo weighted moving average + seasonal index, confidence, risk level, reserve suggestion, 12-month table
8. **Feedback** — viewers/users submit comments, suggestions, concerns from any device (shared server); admin inbox receives, responds, marks New/Reviewed/Resolved, and deletes

## Database (shared server + offline fallback)
Viewer feedback must reach the admin even on different phones/PCs, so the app now uses a tiny shared backend:
- `server.mjs` (zero dependencies) holds ONE database in `server-data.json` and exposes `/api/state` + `/api/feedbacks`.
- The frontend (`src/lib/api.ts`, `src/lib/store.tsx`) pushes every change to the server, polls it every ~4s, and falls back to browser localStorage when the server is unreachable.
- Feedback merges by id, so concurrent viewer + admin writes never overwrite each other.

Run (shared, multi-device):
```bash
cd palo-lgu-budget-ai
npm install
npm run start        # builds + serves on http://localhost:3001
```
Phones/PCs on the same WiFi open `http://<your-laptop-IP>:3001`.
For development, run `npm run server` in one terminal and `npm run dev` in another (vite proxies `/api` to the server).
Single-device/offline mode still works: if the server isn't running, the badge shows "This browser only".

## Forecasting algorithm (`src/lib/forecast.ts`)
- `linearRegression()` OLS slope/intercept/R² over monthly billed totals
- 3-month WMA (0.5/0.3/0.2) blended 60% trend + 40% WMA as anchor
- Seasonal index per calendar month, dampened trend projection × seasonal factor
- Confidence = 40% history length + 35% fit + 25% (1 − volatility); risk Low/Med/High

## Run
```bash
cd palo-lgu-budget-ai
npm install
npm run dev
```
Build: `npm run build`
