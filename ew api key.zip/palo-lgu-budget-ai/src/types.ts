// Core domain models for LGU Palo, Leyte Budget Monitoring System

export type OfficeCode = 'TVS' | 'MHO' | 'MAYOR';

export interface Office {
  code: OfficeCode;
  name: string;
  short: string;
  head: string;
  color: string;
}

export const OFFICES: Office[] = [
  { code: 'TVS', name: 'Palo Technical Vocational School', short: 'Tech-Voc School', head: 'Vocational School Administrator', color: '#2563eb' },
  { code: 'MHO', name: 'Municipal Health Office', short: 'Municipal Health', head: 'Municipal Health Officer', color: '#059669' },
  { code: 'MAYOR', name: "Mayor's Office", short: "Mayor's Office", head: 'Municipal Mayor', color: '#7c3aed' },
];

export function officeName(code: OfficeCode): string {
  return OFFICES.find((o) => o.code === code)?.name ?? code;
}

export interface BankAccount {
  id: string;
  bankName: string;
  accountNo: string;
  accountName: string;
  office: OfficeCode | 'GENERAL';
  ledgerBalance: number;
  bankBalance: number;
  lastVerified: string; // ISO date
  verified: boolean;
  notes?: string;
}

export type ProjectStatus = 'Proposed' | 'Approved' | 'Ongoing' | 'Completed' | 'Deferred';

export interface ActivityProject {
  id: string;
  title: string;
  office: OfficeCode;
  fiscalYear: number;
  category: string;
  description: string;
  startDate: string;
  endDate: string;
  proposedAmount: number;
  approvedAmount: number;
  obligatedAmount: number; // actually disbursed / vouchered
  status: ProjectStatus;
}

export interface Vendor {
  id: string;
  name: string;
  category: string; // e.g. Medical Supplies, Construction, Catering
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
  tin: string;
  philgepsNo?: string;
  rating: number; // 1-5
  active: boolean;
  preferredOffices: OfficeCode[];
}

export type VoucherStatus = 'Pending' | 'Approved' | 'Released' | 'Cancelled';

export interface Voucher {
  id: string;
  voucherNo: string;
  date: string;
  payeeVendorId: string;
  office: OfficeCode;
  activityId: string;
  purpose: string;
  amount: number;
  approvedBy: string;
  status: VoucherStatus;
  remarks?: string;
}

export type BillingStatus = 'Billed' | 'Partial' | 'Paid' | 'Overdue';

export interface Billing {
  id: string;
  vendorId: string;
  office: OfficeCode;
  activityId: string;
  voucherId?: string;
  year: number;
  month: number; // 1-12
  amountBilled: number;
  amountPaid: number;
  dueDate: string;
  status: BillingStatus;
  orNo?: string;
}

export interface AppState {
  accounts: BankAccount[];
  activities: ActivityProject[];
  vendors: Vendor[];
  vouchers: Voucher[];
  billings: Billing[];
  feedbacks: Feedback[];
  events: MunicipalEvent[];
  fiscalYear: number;
}

// ---- Roles & Feedback ----

export type Role = 'admin' | 'viewer';

export type FeedbackType = 'Comment' | 'Suggestion' | 'Concern' | 'Complaint';

export type FeedbackStatus = 'New' | 'Reviewed' | 'Resolved';

export interface Feedback {
  id: string;
  authorName: string;
  authorRole: Role;
  type: FeedbackType;
  office?: string;
  subject: string;
  message: string;
  status: FeedbackStatus;
  response?: string;
  createdAt: string; // ISO datetime
}

// ---- Municipal events (admin posts, viewers read) ----

export type EventStatus = 'Upcoming' | 'Ongoing' | 'Done' | 'Cancelled';

export interface MunicipalEvent {
  id: string;
  title: string;
  description: string;
  venue: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM (24h) or free text like "9:00 AM"
  category: string;
  office?: string; // OfficeCode or '' for general
  status: EventStatus;
  createdAt: string; // ISO datetime
}
