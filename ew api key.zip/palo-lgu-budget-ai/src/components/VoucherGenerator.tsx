import { useState } from 'react';
import { useStore } from '../lib/store';
import { OFFICES, type OfficeCode, type Voucher, type VoucherStatus } from '../types';
import { nextVoucherNo, peso, peso0, todayISO, uid } from '../lib/utils';

const blank = (vendors: { id: string }[], activities: { id: string }[]) => ({
  vendorId: vendors[0]?.id ?? '', office: 'MHO' as OfficeCode, activityId: activities[0]?.id ?? '',
  purpose: '', amount: '', approvedBy: '',
});

export default function VoucherGenerator() {
  const { state, setState, isAdmin } = useStore();
  const [form, setForm] = useState(() => blank(state.vendors, state.activities));
  const [printId, setPrintId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [editingV, setEditingV] = useState<Voucher | null>(null);
  const [editFields, setEditFields] = useState({ purpose: '', date: '', approvedBy: '', remarks: '' });

  const create = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.vendorId || !form.activityId || !form.amount) { alert('Select a vendor, an activity and enter an amount.'); return; }
    if (state.vendors.length === 0 || state.activities.length === 0) { alert('Register at least one vendor and one activity first.'); return; }
    const no = nextVoucherNo(state.vouchers.map((v) => v.voucherNo));
    const id = uid('dv');
    setState((s) => ({
      ...s,
      vouchers: [{ id, voucherNo: no, date: todayISO(), payeeVendorId: form.vendorId, office: form.office, activityId: form.activityId, purpose: form.purpose.trim() || 'Project/event payment', amount: Number(form.amount), approvedBy: form.approvedBy.trim() || '—', status: 'Pending' }, ...s.vouchers],
      activities: s.activities.map((a) => (a.id === form.activityId ? { ...a, obligatedAmount: a.obligatedAmount + Number(form.amount), status: a.status === 'Approved' ? 'Ongoing' : a.status } : a)),
    }));
    setPrintId(id);
    setForm((f) => ({ ...blank(state.vendors, state.activities), office: f.office, approvedBy: f.approvedBy }));
  };

  const setStatus = (id: string, status: VoucherStatus) => {
    setState((s) => ({ ...s, vouchers: s.vouchers.map((v) => (v.id === id ? { ...v, status } : v)) }));
  };

  const startEditV = (v: Voucher) => {
    setEditingV(v);
    setEditFields({ purpose: v.purpose, date: v.date, approvedBy: v.approvedBy, remarks: v.remarks ?? '' });
  };

  const saveEditV = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingV) return;
    setState((s) => ({
      ...s,
      vouchers: s.vouchers.map((v) => (v.id === editingV.id ? { ...v, purpose: editFields.purpose.trim() || v.purpose, date: editFields.date || v.date, approvedBy: editFields.approvedBy.trim() || v.approvedBy, remarks: editFields.remarks.trim() || undefined } : v)),
    }));
    setEditingV(null);
  };

  const remove = (id: string) => {
    const v = state.vouchers.find((x) => x.id === id);
    if (!v) return;
    if (!confirm(`Delete voucher ${v.voucherNo} (${peso0(v.amount)})? Its obligated amount will be returned to the activity budget.`)) return;
    setState((s) => ({
      ...s,
      vouchers: s.vouchers.filter((x) => x.id !== id),
      activities: v.status === 'Cancelled'
        ? s.activities
        : s.activities.map((a) => (a.id === v.activityId ? { ...a, obligatedAmount: Math.max(0, a.obligatedAmount - v.amount) } : a)),
    }));
    if (printId === id) setPrintId(null);
  };

  const list = state.vouchers.filter((v) => (statusFilter === 'ALL' ? true : v.status === statusFilter));
  const vendorOf = (id: string) => state.vendors.find((v) => v.id === id);
  const actOf = (id: string) => state.activities.find((a) => a.id === id);
  const printable = state.vouchers.find((v) => v.id === printId);

  return (
    <div className="grid" style={{ gap: 14 }}>
      {!isAdmin && <div className="alert">👁️ View-only mode — only the administrator can generate, approve or delete vouchers. You may still preview and print.</div>}
      <div className="grid g2">
        {isAdmin && !editingV && (
        <div className="card">
          <h3>🧾 Generate Disbursement Voucher</h3>
          <p className="sub">For project or event approvals. Auto-numbers LGU-PALO-YYYY-XXXXXX and obligates the activity budget.</p>
          {state.vendors.length === 0 || state.activities.length === 0 ? (
            <div className="empty">Register at least one vendor/business and one activity/project first (see Vendors and Annual Budget tabs).</div>
          ) : (
          <form className="grid2" onSubmit={create}>
            <label className="f">Payee vendor<select value={form.vendorId} onChange={(e) => setForm({ ...form, vendorId: e.target.value })}><option value="">— Select vendor —</option>{state.vendors.filter((v) => v.active).map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}</select></label>
            <label className="f">Charge to office<select value={form.office} onChange={(e) => setForm({ ...form, office: e.target.value as OfficeCode })}>{OFFICES.map((o) => <option key={o.code} value={o.code}>{o.name}</option>)}</select></label>
            <label className="f" style={{ gridColumn: '1 / -1' }}>Activity / Event<select value={form.activityId} onChange={(e) => setForm({ ...form, activityId: e.target.value })}><option value="">— Select activity —</option>{state.activities.filter((a) => a.fiscalYear === state.fiscalYear).map((a) => <option key={a.id} value={a.id}>{a.title} ({a.office}) — bal {peso0(a.approvedAmount - a.obligatedAmount)}</option>)}</select></label>
            <label className="f" style={{ gridColumn: '1 / -1' }}>Purpose / Particulars<textarea value={form.purpose} onChange={(e) => setForm({ ...form, purpose: e.target.value })} rows={2} placeholder="e.g. Catering for 200 pax — Fiesta opening parade" /></label>
            <label className="f">Amount (₱)<input type="number" min={0} value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="0" /></label>
            <label className="f">Approved by<input value={form.approvedBy} onChange={(e) => setForm({ ...form, approvedBy: e.target.value })} placeholder="e.g. Municipal Mayor" /></label>
            <div style={{ gridColumn: '1 / -1' }}><button className="btn primary" type="submit">Generate voucher</button></div>
          </form>
          )}
        </div>
        )}
        {isAdmin && editingV && (
        <div className="card">
          <h3>Edit voucher {editingV.voucherNo}</h3>
          <p className="sub">Only details may be edited here (amount changes require deleting and re-issuing, so the budget obligation stays audit-clean).</p>
          <form className="grid2" onSubmit={saveEditV}>
            <label className="f">Date<input type="date" value={editFields.date} onChange={(e) => setEditFields({ ...editFields, date: e.target.value })} /></label>
            <label className="f">Approved by<input value={editFields.approvedBy} onChange={(e) => setEditFields({ ...editFields, approvedBy: e.target.value })} /></label>
            <label className="f" style={{ gridColumn: '1 / -1' }}>Purpose<textarea value={editFields.purpose} onChange={(e) => setEditFields({ ...editFields, purpose: e.target.value })} rows={2} /></label>
            <label className="f" style={{ gridColumn: '1 / -1' }}>Remarks<textarea value={editFields.remarks} onChange={(e) => setEditFields({ ...editFields, remarks: e.target.value })} rows={2} /></label>
            <div className="row"><button className="btn primary" type="submit">Save changes</button><button type="button" className="btn ghost" onClick={() => setEditingV(null)}>Cancel</button></div>
          </form>
        </div>
        )}
        <div className="card">
          <h3>🖨️ Voucher preview / print</h3>
          {!printable ? <p className="sub">Generate or click “Print” on any voucher below to preview the official format.</p> : (
            <div className="voucher-paper">
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <div><strong>Republic of the Philippines</strong><br />Municipality of Palo, Leyte<br /><strong>DISBURSEMENT VOUCHER</strong></div>
                <div style={{ textAlign: 'right' }}><strong>{printable.voucherNo}</strong><br />{printable.date}</div>
              </div>
              <hr />
              <p><strong>Payee:</strong> {vendorOf(printable.payeeVendorId)?.name ?? '(vendor removed)'}<br />
                <strong>Office:</strong> {OFFICES.find((o) => o.code === printable.office)?.name}<br />
                <strong>Activity:</strong> {actOf(printable.activityId)?.title ?? '(activity removed)'}<br />
                <strong>Purpose:</strong> {printable.purpose}</p>
              <p style={{ fontSize: 22, fontWeight: 800 }}>{peso(printable.amount)}</p>
              <p style={{ fontSize: 12 }}>Approved by: <strong>{printable.approvedBy}</strong> · Status: <strong>{printable.status}</strong></p>
              <div className="row no-print">
                <button className="btn dark small" onClick={() => window.print()}>Print / Save PDF</button>
                <button className="btn ghost small" onClick={() => setPrintId(null)}>Close</button>
              </div>
            </div>
          )}
        </div>
      </div>
      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <h3>Voucher registry ({list.length})</h3>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} style={{ width: 160 }}>
            {['ALL', 'Pending', 'Approved', 'Released', 'Cancelled'].map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
        {state.vouchers.length === 0 ? (
          <div className="empty">{isAdmin ? 'No vouchers yet. Generate the first disbursement voucher above.' : 'No vouchers encoded yet.'}</div>
        ) : (
        <table className="tbl">
          <thead><tr><th>Voucher No.</th><th>Payee / Purpose</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {list.map((v) => (
              <tr key={v.id}>
                <td><strong>{v.voucherNo}</strong><br /><span style={{ fontSize: 11, color: '#64748b' }}>{v.date}</span></td>
                <td><strong>{vendorOf(v.payeeVendorId)?.name ?? '(vendor removed)'}</strong><br /><span style={{ fontSize: 12 }}>{v.purpose}</span><br /><span style={{ fontSize: 11, color: '#64748b' }}>{actOf(v.activityId)?.title ?? ''}</span></td>
                <td><strong>{peso0(v.amount)}</strong></td>
                <td><span className={`pill ${v.status === 'Released' ? 'ok' : v.status === 'Cancelled' ? 'bad' : v.status === 'Approved' ? 'info' : 'warn'}`}>{v.status}</span></td>
                <td><div className="row">
                  <button className="btn small ghost" onClick={() => setPrintId(v.id)}>Print</button>
                  {isAdmin && v.status === 'Pending' && <button className="btn small primary" onClick={() => setStatus(v.id, 'Approved')}>Approve</button>}
                  {isAdmin && v.status === 'Approved' && <button className="btn small primary" onClick={() => setStatus(v.id, 'Released')}>Release</button>}
                  {isAdmin && v.status !== 'Cancelled' && v.status !== 'Released' && <button className="btn small danger" onClick={() => setStatus(v.id, 'Cancelled')}>Cancel</button>}
                  {isAdmin && <button className="btn small ghost" onClick={() => startEditV(v)}>Edit</button>}
                  {isAdmin && <button className="btn small danger" onClick={() => remove(v.id)}>Delete</button>}
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
        )}
      </div>
    </div>
  );
}
