import { useState } from 'react';
import { useStore } from '../lib/store';
import { officeName } from '../types';
import { peso, todayISO, uid } from '../lib/utils';

export default function BankVerification() {
  const { state, setState, isAdmin } = useStore();
  const [form, setForm] = useState({ bankName: '', accountNo: '', accountName: '', office: 'GENERAL' as string, ledgerBalance: '', bankBalance: '' });

  const verify = (id: string) => {
    setState((s) => ({
      ...s,
      accounts: s.accounts.map((a) =>
        a.id === id ? { ...a, verified: Math.abs(a.bankBalance - a.ledgerBalance) < 1, lastVerified: todayISO(), notes: Math.abs(a.bankBalance - a.ledgerBalance) < 1 ? 'Reconciled — no variance' : a.notes } : a
      ),
    }));
  };

  const updateBalances = (id: string, field: 'ledgerBalance' | 'bankBalance', val: number) => {
    setState((s) => ({
      ...s,
      accounts: s.accounts.map((a) => (a.id === id ? { ...a, [field]: val, verified: false } : a)),
    }));
  };

  const remove = (id: string) => {
    if (!confirm('Delete this bank account record?')) return;
    setState((s) => ({ ...s, accounts: s.accounts.filter((a) => a.id !== id) }));
  };

  const add = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.accountNo.trim() || !form.accountName.trim()) {
      alert('Account name and account number are required.');
      return;
    }
    setState((s) => ({
      ...s,
      accounts: [
        ...s.accounts,
        {
          id: uid('b'),
          bankName: form.bankName.trim() || '—',
          accountNo: form.accountNo.trim(),
          accountName: form.accountName.trim(),
          office: form.office as 'GENERAL' | 'TVS' | 'MHO' | 'MAYOR',
          ledgerBalance: Number(form.ledgerBalance) || 0,
          bankBalance: Number(form.bankBalance) || 0,
          lastVerified: todayISO(),
          verified: false,
        },
      ],
    }));
    setForm({ bankName: '', accountNo: '', accountName: '', office: 'GENERAL', ledgerBalance: '', bankBalance: '' });
  };

  return (
    <div className="grid" style={{ gap: 14 }}>
      {!isAdmin && <div className="alert">👁️ View-only mode — only the administrator can add, edit, verify or delete bank records.</div>}
      <div className="card">
        <h3>🏦 Bank Balance Verification — LGU Palo, Leyte</h3>
        <p className="sub">Compare Treasurer's ledger vs bank statement. Verify each account; variances must be resolved before budget release (COA audit rule).</p>
        {state.accounts.length === 0 ? (
          <div className="empty">{isAdmin ? 'No bank accounts yet. Add the first account using the form below.' : 'No bank accounts have been encoded yet. Records will appear here once the administrator adds them.'}</div>
        ) : (
        <table className="tbl">
          <thead><tr><th>Account</th><th>Ledger (Books)</th><th>Bank Statement</th><th>Variance</th><th>Status</th>{isAdmin && <th>Action</th>}</tr></thead>
          <tbody>
            {state.accounts.map((a) => {
              const v = a.bankBalance - a.ledgerBalance;
              return (
                <tr key={a.id}>
                  <td>
                    <strong>{a.accountName}</strong><br />
                    <span style={{ fontSize: 12, color: '#64748b' }}>{a.bankName} · {a.accountNo}</span><br />
                    <span className="pill info" style={{ marginTop: 4 }}>{a.office === 'GENERAL' ? 'General Fund' : officeName(a.office as 'TVS' | 'MHO' | 'MAYOR')}</span>
                    <div style={{ fontSize: 11, color: '#64748b' }}>Last verified: {a.lastVerified}{a.notes ? ` — ${a.notes}` : ''}</div>
                  </td>
                  <td>{isAdmin ? <input type="number" value={a.ledgerBalance} onChange={(e) => updateBalances(a.id, 'ledgerBalance', Number(e.target.value))} /> : <strong>{peso(a.ledgerBalance)}</strong>}</td>
                  <td>{isAdmin ? <input type="number" value={a.bankBalance} onChange={(e) => updateBalances(a.id, 'bankBalance', Number(e.target.value))} /> : <strong>{peso(a.bankBalance)}</strong>}</td>
                  <td style={{ fontWeight: 800, color: Math.abs(v) < 1 ? '#059669' : '#dc2626' }}>{peso(v)}</td>
                  <td>{a.verified && Math.abs(v) < 1 ? <span className="pill ok">✓ Verified</span> : <span className="pill bad">Unreconciled</span>}</td>
                  {isAdmin && (
                    <td><div className="row">
                      <button className="btn small primary" onClick={() => verify(a.id)}>Verify</button>
                      <button className="btn small danger" onClick={() => remove(a.id)}>Delete</button>
                    </div></td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
        )}
      </div>
      {isAdmin && (
      <div className="card">
        <h3>＋ Add bank account</h3>
        <form className="grid2" onSubmit={add}>
          <label className="f">Bank<input value={form.bankName} onChange={(e) => setForm({ ...form, bankName: e.target.value })} placeholder="e.g. Land Bank — Palo Branch" /></label>
          <label className="f">Account name<input value={form.accountName} onChange={(e) => setForm({ ...form, accountName: e.target.value })} placeholder="e.g. General Fund" /></label>
          <label className="f">Account no.<input value={form.accountNo} onChange={(e) => setForm({ ...form, accountNo: e.target.value })} placeholder="0000-0000-00" /></label>
          <label className="f">Office
            <select value={form.office} onChange={(e) => setForm({ ...form, office: e.target.value })}>
              <option value="GENERAL">General Fund</option>
              <option value="TVS">Tech-Voc School</option>
              <option value="MHO">Municipal Health</option>
              <option value="MAYOR">Mayor's Office</option>
            </select>
          </label>
          <label className="f">Ledger balance (₱)<input type="number" value={form.ledgerBalance} onChange={(e) => setForm({ ...form, ledgerBalance: e.target.value })} placeholder="0" /></label>
          <label className="f">Bank balance (₱)<input type="number" value={form.bankBalance} onChange={(e) => setForm({ ...form, bankBalance: e.target.value })} placeholder="0" /></label>
          <div><button className="btn dark" type="submit">Add account</button></div>
        </form>
      </div>
      )}
    </div>
  );
}
