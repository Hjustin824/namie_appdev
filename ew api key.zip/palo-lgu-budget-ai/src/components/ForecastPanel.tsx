import { useEffect, useMemo, useState } from 'react';
import { useStore } from '../lib/store';
import { forecastVendor, getVendorMonthlySeries, monthLabel } from '../lib/forecast';
import { downloadCSV, peso0, toCSV } from '../lib/utils';
import { Bars, historyPlusForecast } from './Charts';
import { buildDemoData } from '../lib/demo';

type Scenario = 'Conservative' | 'Expected' | 'Aggressive';

export default function ForecastPanel() {
  const { state, setState, isAdmin } = useStore();
  const [vendorId, setVendorId] = useState('');
  const [reservePct, setReservePct] = useState(10);
  const [horizon, setHorizon] = useState<3 | 6 | 12>(12);
  const [scenario, setScenario] = useState<Scenario>('Expected');

  // Auto-select the first encoded vendor (data starts empty).
  useEffect(() => {
    if (!state.vendors.some((v) => v.id === vendorId)) {
      setVendorId(state.vendors[0]?.id ?? '');
    }
  }, [state.vendors, vendorId]);

  const f = useMemo(() => forecastVendor(state.billings, vendorId), [state.billings, vendorId]);
  const vendor = state.vendors.find((v) => v.id === vendorId);
  const chart = historyPlusForecast(state.billings, vendorId, f.next12Months);
  const forecastFrom = Math.max(0, chart.length - 4);
  const history = useMemo(() => getVendorMonthlySeries(state.billings, vendorId).slice(-8).reverse(), [state.billings, vendorId]);

  const scenarioMonths = scenario === 'Conservative' ? f.low12Months : scenario === 'Aggressive' ? f.high12Months : f.next12Months;
  const shownMonths = scenarioMonths.slice(0, horizon);
  const scenarioAnnual = scenarioMonths.reduce((a, b) => a + b.amount, 0);
  const reserve = Math.round((scenarioAnnual * reservePct) / 100);

  const all = state.vendors
    .map((v) => ({ v, f: forecastVendor(state.billings, v.id) }))
    .sort((a, b) => b.f.annualForecast - a.f.annualForecast);

  const loadDemo = () => {
    if (!confirm('Load demo vendors + 18 months of billings so the forecast works instantly? (Labeled DEMO — you can Clear all data afterwards.)')) return;
    const demo = buildDemoData();
    setState((s) => ({ ...s, vendors: [...s.vendors, ...demo.vendors], billings: [...s.billings, ...demo.billings] }));
    setVendorId(demo.vendors[0].id);
  };

  const exportCSV = () => {
    if (!vendor) return;
    const csv = toCSV(
      shownMonths.map((m, i) => {
        const low = f.low12Months[i]?.amount ?? 0;
        const high = f.high12Months[i]?.amount ?? 0;
        return {
          Vendor: vendor.name,
          Month: monthLabel(m.year, m.month),
          Scenario: scenario,
          Expected: f.next12Months[i]?.amount ?? 0,
          Low: low,
          High: high,
          Shown: m.amount,
        };
      })
    );
    downloadCSV(`forecast-${vendor.name.replace(/\W+/g, '-').toLowerCase()}-${horizon}mo.csv`, csv);
  };

  return (
    <div className="grid" style={{ gap: 14 }}>
      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div>
            <h3>🤖 AI Vendor Forecasting Engine</h3>
            <p className="sub">Hybrid algorithm: OLS linear trend + 3-month weighted moving average + monthly seasonal index. Explainable & auditable. Forecasts are computed live from encoded billing records.</p>
          </div>
          <div className="row">
            <select value={vendorId} onChange={(e) => setVendorId(e.target.value)} style={{ width: 260 }}>
              {state.vendors.length === 0 && <option value="">— No vendors encoded —</option>}
              {state.vendors.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
            </select>
            <select value={horizon} onChange={(e) => setHorizon(Number(e.target.value) as 3 | 6 | 12)} style={{ width: 130 }} title="Forecast horizon">
              <option value={3}>Next 3 mo</option>
              <option value={6}>Next 6 mo</option>
              <option value={12}>Next 12 mo</option>
            </select>
            <select value={scenario} onChange={(e) => setScenario(e.target.value as Scenario)} style={{ width: 150 }} title="Budget scenario">
              <option>Conservative</option>
              <option>Expected</option>
              <option>Aggressive</option>
            </select>
          </div>
        </div>
        {!vendor ? (
          <div>
            <div className="empty">No vendors with billing history yet. Encode vendors + monthly billings in Billing Reports — or load a one-click demo dataset to see the engine work instantly.</div>
            {isAdmin && (
              <div className="row" style={{ marginTop: 10 }}>
                <button className="btn primary small" onClick={loadDemo}>⚡ Load demo dataset (4 vendors · 18 months)</button>
              </div>
            )}
          </div>
        ) : (
          <div className="grid g2" style={{ marginTop: 8 }}>
            <div>
              <h3 style={{ fontSize: 13 }}>History (last 8 mo, solid) + forecast (next 4 mo, hatched)</h3>
              <Bars data={chart} color="#7c3aed" forecastFrom={forecastFrom} />
              <div className="alert ok" style={{ marginTop: 10 }}>💡 {f.recommendation}</div>
              <div className="alert">🧮 <strong>How it works:</strong> {f.explanation}</div>
              <details style={{ marginTop: 8 }}>
                <summary style={{ cursor: 'pointer', fontSize: 13, fontWeight: 700 }}>📜 Actual billing history (last 8 months)</summary>
                <table className="tbl">
                  <thead><tr><th>Month</th><th>Billed</th></tr></thead>
                  <tbody>
                    {history.length === 0 && <tr><td colSpan={2}>No history.</td></tr>}
                    {history.map((h) => <tr key={`${h.year}-${h.month}`}><td>{monthLabel(h.year, h.month)}</td><td><strong>{peso0(h.total)}</strong></td></tr>)}
                  </tbody>
                </table>
              </details>
            </div>
            <div>
              <div className="grid g2">
                <div className="card" style={{ background: '#f5f3ff' }}>
                  <div style={{ fontSize: 12, color: '#64748b' }}>{scenario} {horizon}-mo forecast</div>
                  <div style={{ fontSize: 22, fontWeight: 800 }}>{peso0(shownMonths.reduce((a, b) => a + b.amount, 0))}</div>
                  <div style={{ fontSize: 11, color: '#64748b' }}>avg {peso0(f.avgMonthly)}/mo · {f.historyMonths} mo history · 12-mo {peso0(scenarioAnnual)}</div>
                </div>
                <div className="card" style={{ background: '#f8fafc' }}>
                  <div style={{ fontSize: 12, color: '#64748b' }}>Trend · R² fit</div>
                  <div style={{ fontSize: 22, fontWeight: 800 }}>{f.trendDirection}</div>
                  <div style={{ fontSize: 11, color: '#64748b' }}>{peso0(f.trendSlope)}/mo slope · R² {f.r2.toFixed(2)}{f.yoyGrowth !== null ? ` · YoY ${f.yoyGrowth > 0 ? '+' : ''}${f.yoyGrowth}%` : ''}</div>
                </div>
                <div className="card" style={{ background: '#eff6ff' }}>
                  <div style={{ fontSize: 12, color: '#64748b' }}>Confidence · Accuracy</div>
                  <div style={{ fontSize: 22, fontWeight: 800 }}>{f.confidence}%</div>
                  <div style={{ fontSize: 11, color: '#64748b' }}>MAPE {f.mape.toFixed(1)}% · vol {(f.volatility * 100).toFixed(1)}%</div>
                  <div style={{ marginTop: 4 }}><span className={`pill ${f.riskLevel === 'Low' ? 'ok' : f.riskLevel === 'Medium' ? 'warn' : 'bad'}`}>{f.riskLevel} risk</span></div>
                </div>
                <div className="card" style={{ background: '#fefce8' }}>
                  <div style={{ fontSize: 12, color: '#64748b' }}>Suggested reserve ({reservePct}%)</div>
                  <div style={{ fontSize: 22, fontWeight: 800 }}>{peso0(reserve)}</div>
                  <input type="range" min={0} max={30} value={reservePct} onChange={(e) => setReservePct(Number(e.target.value))} />
                </div>
              </div>
              <div className="row" style={{ margin: '12px 0 6px', justifyContent: 'space-between' }}>
                <h3 style={{ fontSize: 13, margin: 0 }}>Forecast breakdown — {scenario} ({horizon} mo)</h3>
                <button className="btn small ghost" onClick={exportCSV}>⬇ Export CSV</button>
              </div>
              <table className="tbl">
                <thead><tr><th>Month</th><th>Expected</th><th>Low – High</th><th>Budget ({scenario})</th></tr></thead>
                <tbody>
                  {shownMonths.map((m, i) => (
                    <tr key={`${m.year}-${m.month}`}>
                      <td>{monthLabel(m.year, m.month)}</td>
                      <td>{peso0(f.next12Months[i]?.amount ?? 0)}</td>
                      <td style={{ fontSize: 12, color: '#64748b' }}>{peso0(f.low12Months[i]?.amount ?? 0)} – {peso0(f.high12Months[i]?.amount ?? 0)}</td>
                      <td><strong>{peso0(m.amount)}</strong></td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <details style={{ marginTop: 8 }}>
                <summary style={{ cursor: 'pointer', fontSize: 13, fontWeight: 700 }}>🔍 Model transparency (audit details)</summary>
                <div style={{ fontSize: 12, color: '#334155', lineHeight: 1.6, marginTop: 6 }}>
                  <div><strong>Method:</strong> 60% OLS trend-line endpoint + 40% 3-month weighted moving average (0.5/0.3/0.2), then × seasonal index per calendar month, trend dampened ×0.85 per step.</div>
                  <div><strong>Fit:</strong> R² {f.r2.toFixed(3)} (1.0 = perfect trend fit) · MAPE {f.mape.toFixed(1)}% mean error of trend vs actuals · {f.historyMonths} months of history.</div>
                  <div><strong>Seasonality:</strong> peak {monthLabel(2026, f.seasonalPeakMonth).split(' ')[0]} (×{f.seasonalIndex[f.seasonalPeakMonth - 1].toFixed(2)}). Bands = ±{Math.round(Math.min(0.6, Math.max(0.05, f.volatility) * 0.9) * 100)}% from volatility.</div>
                  <div><strong>Risk rule:</strong> High if volatility &gt; 65% or confidence &lt; 45 · Medium if volatility &gt; 35% or confidence &lt; 70 · else Low.</div>
                </div>
              </details>
            </div>
          </div>
        )}
      </div>
      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div>
            <h3>All-vendor forecast ranking (next 12 months)</h3>
            <p className="sub">Use this table to set the FY annual budget ceilings per vendor / category.</p>
          </div>
          {isAdmin && state.vendors.length === 0 && (
            <button className="btn small primary" onClick={loadDemo}>⚡ Load demo dataset</button>
          )}
        </div>
        {all.length === 0 ? (
          <div className="empty">No vendors encoded yet.</div>
        ) : (
        <table className="tbl">
          <thead><tr><th>Vendor</th><th>Trend</th><th>Avg/mo</th><th>12-mo forecast</th><th>Range (low–high)</th><th>Confidence</th><th>Risk</th></tr></thead>
          <tbody>
            {all.map(({ v, f: x }) => (
              <tr key={v.id} style={{ background: v.id === vendorId ? '#f5f3ff' : undefined, cursor: 'pointer' }} onClick={() => setVendorId(v.id)}>
                <td><strong>{v.name}</strong><br /><span style={{ fontSize: 11, color: '#64748b' }}>{v.category}</span></td>
                <td>{x.historyMonths === 0 ? '—' : `${x.trendDirection}${x.yoyGrowth !== null ? ` (${x.yoyGrowth > 0 ? '+' : ''}${x.yoyGrowth}% YoY)` : ''}`}</td>
                <td>{peso0(x.avgMonthly)}</td>
                <td><strong>{peso0(x.annualForecast)}</strong></td>
                <td style={{ fontSize: 12, color: '#64748b' }}>{peso0(x.low12Months.reduce((a, b) => a + b.amount, 0))} – {peso0(x.high12Months.reduce((a, b) => a + b.amount, 0))}</td>
                <td>{x.confidence}% <span style={{ fontSize: 11, color: '#64748b' }}>· MAPE {x.mape.toFixed(0)}%</span></td>
                <td><span className={`pill ${x.riskLevel === 'Low' ? 'ok' : x.riskLevel === 'Medium' ? 'warn' : 'bad'}`}>{x.riskLevel}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
        )}
      </div>
    </div>
  );
}
