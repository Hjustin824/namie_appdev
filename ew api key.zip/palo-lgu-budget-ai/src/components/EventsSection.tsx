import { useState } from 'react';
import { useStore } from '../lib/store';
import { OFFICES, type EventStatus, type MunicipalEvent } from '../types';
import { todayISO, uid } from '../lib/utils';

const CATS = [
  'General',
  'Fiesta / Celebration',
  'Health Program',
  'Sports',
  'Public Hearing',
  'Disaster Drill',
  'Livelihood',
  'Socio-Cultural',
  'Infrastructure',
  'Other',
];

const STATUSES: EventStatus[] = ['Upcoming', 'Ongoing', 'Done', 'Cancelled'];

function statusPill(s: EventStatus): string {
  return s === 'Upcoming' ? 'info' : s === 'Ongoing' ? 'ok' : s === 'Done' ? 'vio' : 'bad';
}

function fmtDate(iso: string): string {
  if (!iso) return '—';
  const d = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-PH', { month: 'long', day: 'numeric', year: 'numeric' });
}

const blank = () => ({
  title: '',
  description: '',
  venue: '',
  date: todayISO(),
  time: '',
  category: CATS[0],
  office: '',
  status: 'Upcoming' as EventStatus,
});

export function upcomingEvents(events: MunicipalEvent[], today = todayISO()): MunicipalEvent[] {
  return events
    .filter((e) => (e.status === 'Upcoming' || e.status === 'Ongoing') && e.date >= today)
    .sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time));
}

export default function EventsSection() {
  const { state, setState, isAdmin } = useStore();
  const [form, setForm] = useState(blank());
  const [editing, setEditing] = useState<MunicipalEvent | null>(null);
  const [statusFilter, setStatusFilter] = useState('ALL');

  const sorted = [...state.events].sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time));
  const adminList = sorted.filter((e) => statusFilter === 'ALL' || e.status === statusFilter);
  const viewerList = upcomingEvents(state.events);

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) {
      alert('Event title is required.');
      return;
    }
    if (!form.date) {
      alert('Event date is required.');
      return;
    }
    if (editing) {
      setState((s) => ({
        ...s,
        events: s.events.map((x) =>
          x.id === editing.id
            ? {
                ...x,
                title: form.title.trim(),
                description: form.description.trim(),
                venue: form.venue.trim(),
                date: form.date,
                time: form.time.trim(),
                category: form.category,
                office: form.office || undefined,
                status: form.status,
              }
            : x
        ),
      }));
      setEditing(null);
    } else {
      const ev: MunicipalEvent = {
        id: uid('ev'),
        title: form.title.trim(),
        description: form.description.trim(),
        venue: form.venue.trim(),
        date: form.date,
        time: form.time.trim(),
        category: form.category,
        office: form.office || undefined,
        status: form.status,
        createdAt: new Date().toISOString(),
      };
      setState((s) => ({ ...s, events: [...s.events, ev] }));
    }
    setForm(blank());
  };

  const startEdit = (ev: MunicipalEvent) => {
    setEditing(ev);
    setForm({
      title: ev.title,
      description: ev.description,
      venue: ev.venue,
      date: ev.date,
      time: ev.time,
      category: ev.category,
      office: ev.office ?? '',
      status: ev.status,
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const remove = (id: string) => {
    if (!confirm('Delete this event permanently? Viewers will no longer see it.')) return;
    setState((s) => ({ ...s, events: s.events.filter((x) => x.id !== id) }));
    if (editing?.id === id) {
      setEditing(null);
      setForm(blank());
    }
  };

  const markStatus = (id: string, status: EventStatus) => {
    setState((s) => ({ ...s, events: s.events.map((x) => (x.id === id ? { ...x, status } : x)) }));
  };

  return (
    <div className="grid" style={{ gap: 14 }}>
      {isAdmin && (
        <div className="card">
          <h3>{editing ? '✏️ Edit event' : '📅 Post a municipal event'}</h3>
          <p className="sub">
            {editing
              ? 'Update the details below. Changes appear for viewers instantly.'
              : 'Announce fiestas, assemblies, health missions, drills and more. Published events appear for viewers right away.'}
          </p>
          <form className="grid2" onSubmit={save}>
            <label className="f" style={{ gridColumn: '1 / -1' }}>
              Event title *
              <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Palo Fiesta Grand Parade" />
            </label>
            <label className="f">
              Date *
              <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            </label>
            <label className="f">
              Time
              <input value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} placeholder="e.g. 8:00 AM" />
            </label>
            <label className="f">
              Venue
              <input value={form.venue} onChange={(e) => setForm({ ...form, venue: e.target.value })} placeholder="e.g. Palo Municipal Plaza" />
            </label>
            <label className="f">
              Category
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                {CATS.map((c) => <option key={c}>{c}</option>)}
              </select>
            </label>
            <label className="f">
              Organizing office
              <select value={form.office} onChange={(e) => setForm({ ...form, office: e.target.value })}>
                <option value="">— General / Whole municipality —</option>
                {OFFICES.map((o) => <option key={o.code} value={o.code}>{o.name}</option>)}
              </select>
            </label>
            <label className="f">
              Status
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as EventStatus })}>
                {STATUSES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </label>
            <label className="f" style={{ gridColumn: '1 / -1' }}>
              Details / description
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} placeholder="What will happen, who should attend, what to bring…" />
            </label>
            <div className="row" style={{ gridColumn: '1 / -1' }}>
              <button className="btn primary" type="submit">{editing ? 'Save changes' : 'Publish event'}</button>
              {editing && (
                <button
                  className="btn ghost"
                  type="button"
                  onClick={() => {
                    setEditing(null);
                    setForm(blank());
                  }}
                >
                  Cancel edit
                </button>
              )}
            </div>
          </form>
        </div>
      )}

      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div>
            <h3>{isAdmin ? `📋 All events (${adminList.length})` : '📅 Upcoming events in Palo'}</h3>
            <p className="sub">
              {isAdmin
                ? 'Manage every announcement. Only Upcoming / Ongoing events with today or future dates show to viewers.'
                : 'Official announcements from the municipality — mark your calendar!'}
            </p>
          </div>
          {isAdmin && (
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} style={{ width: 160 }}>
              <option value="ALL">All statuses</option>
              {STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
          )}
        </div>

        {(isAdmin ? adminList : viewerList).length === 0 ? (
          <div className="empty">
            {isAdmin
              ? 'No events yet. Publish the first one with the form above.'
              : 'No upcoming events posted yet. Please check back soon!'}
          </div>
        ) : (
          <div className="grid g3">
            {(isAdmin ? adminList : viewerList).map((ev) => (
              <div key={ev.id} className="card" style={{ background: '#f8fafc' }}>
                <div className="row" style={{ justifyContent: 'space-between' }}>
                  <span className={`pill ${statusPill(ev.status)}`}>{ev.status}</span>
                  <span style={{ fontSize: 11, color: '#64748b' }}>{ev.category}</span>
                </div>
                <div style={{ fontSize: 16, fontWeight: 800, margin: '8px 0 2px' }}>{ev.title}</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#1d4ed8' }}>
                  📆 {fmtDate(ev.date)}{ev.time ? ` · 🕘 ${ev.time}` : ''}
                </div>
                {ev.venue && <div style={{ fontSize: 12, color: '#475569', marginTop: 2 }}>📍 {ev.venue}</div>}
                {ev.office && (
                  <div style={{ fontSize: 11, color: '#64748b', marginTop: 2 }}>
                    {OFFICES.find((o) => o.code === ev.office)?.short ?? ev.office}
                  </div>
                )}
                {ev.description && <p style={{ fontSize: 12, margin: '8px 0 0', color: '#334155' }}>{ev.description}</p>}
                {isAdmin && (
                  <div className="row no-print" style={{ marginTop: 10 }}>
                    <button className="btn small ghost" onClick={() => startEdit(ev)}>Edit</button>
                    {STATUSES.filter((s) => s !== ev.status).map((s) => (
                      <button key={s} className="btn small ghost" onClick={() => markStatus(ev.id, s)}>
                        Mark {s}
                      </button>
                    ))}
                    <button className="btn small danger" onClick={() => remove(ev.id)}>Delete</button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
