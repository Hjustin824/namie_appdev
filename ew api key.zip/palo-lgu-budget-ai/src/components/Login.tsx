import { useState } from 'react';
import { useStore } from '../lib/store';
import { DEFAULT_ADMIN_PASS, DEFAULT_ADMIN_USER } from '../lib/db';

export default function Login() {
  const { loginAdmin, loginViewer } = useStore();
  const [viewerName, setViewerName] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [err, setErr] = useState('');

  const doViewer = (e: React.FormEvent) => {
    e.preventDefault();
    loginViewer(viewerName || 'Guest Viewer');
  };

  const doAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginAdmin(adminPass)) {
      setErr('');
    } else {
      setErr('Incorrect admin password. Please try again.');
    }
  };

  return (
    <div className="login-wrap">
      <div className="login-head">
        <div className="seal"><img src="/palo-seal.png" alt="Municipality of Palo seal" onError={(e) => { e.currentTarget.src = '/palo-seal.svg'; }} /></div>
        <h1>LGU Palo, Leyte — AI Budget Monitoring System</h1>
        <p>Technical Vocational School · Municipal Health Office · Mayor's Office</p>
      </div>
      <div className="grid g2 login-grid">
        <div className="card login-card">
          <h3>👁️ Continue as Viewer / User</h3>
          <p className="sub">Dashboard-only access. Viewers can see the dashboard summary and send feedback, comments, suggestions or concerns — but cannot open bank, budget, vendor, voucher or report records.</p>
          <form onSubmit={doViewer}>
            <label className="f">Your name (for feedback records)<input value={viewerName} onChange={(e) => setViewerName(e.target.value)} placeholder="e.g. Juan Dela Cruz" /></label>
            <div style={{ marginTop: 10 }}><button className="btn dark" type="submit">Enter as Viewer →</button></div>
          </form>
        </div>
        <div className="card login-card admin">
          <h3>🔐 Administrator Login</h3>
          <p className="sub">Full control: add, edit and delete all records, verify bank balances, approve vouchers, and receive / manage feedback. Admins cannot send feedback — only review and respond.</p>
          <form onSubmit={doAdmin}>
            <label className="f">Username<input value={DEFAULT_ADMIN_USER} disabled /></label>
            <label className="f">Password<input type="password" value={adminPass} onChange={(e) => setAdminPass(e.target.value)} placeholder="Enter admin password" /></label>
            {err && <div className="alert bad">{err}</div>}
            <div style={{ marginTop: 10 }}><button className="btn primary" type="submit">Log in as Admin →</button></div>
          </form>
          <p style={{ fontSize: 11, color: '#64748b', marginTop: 10 }}>Default password: <code>{DEFAULT_ADMIN_PASS}</code> (changeable inside the app via the sidebar).</p>
        </div>
      </div>
      <p style={{ fontSize: 11, color: '#64748b', textAlign: 'center' }}>All records are stored in the system database. The system starts empty — the admin encodes all figures.</p>
    </div>
  );
}
