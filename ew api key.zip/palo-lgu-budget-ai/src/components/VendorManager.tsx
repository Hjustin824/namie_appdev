import { useState } from 'react';
import { useStore } from '../lib/store';
import type { OfficeCode, Vendor } from '../types';
import { peso0, uid } from '../lib/utils';
import { forecastVendor } from '../lib/forecast';

const blank = () => ({ name: '', category: '', contactPerson: '', phone: '', email: '', address: '', tin: '', philgepsNo: '', rating: '4' });

export default function VendorManager() {
  const { state, setState, isAdmin } = useStore();
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('ALL');
  const [form, setForm] = useState(blank());
  const [editing, setEditing] = useState<Vendor | null>(null);

  const cats = ['ALL', ...Array.from(new Set(state.vendors.map((v) => v.category).filter(Boolean)))];
  const list = state.vendors.filter((v) =>
    (cat === 'ALL' || v.category === cat) &&
    (q === '' || (v.name + v.contactPerson + v.address + v.tin).toLowerCase().includes(q.toLowerCase()))
  );

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      alert('Business name is required.');
      return;
    }
    if (editing) {
      setState((s) => ({
        ...s,
        vendors: s.vendors.map((v) => (v.id === editing.id ? { ...v, name: form.name.trim(), category: form.category.trim() || 'General', contactPerson: form.contactPerson, phone: form.phone, email: form.email, address: form.address, tin: form.tin, philgepsNo: form.philgepsNo || undefined, rating: Math.min(5, Math.max(1, Number(form.rating) || 4)) } : v)),
      }));
      setEditing(null);
    } else {
      const v: Vendor = {
        id: uid('v'), name: form.name.trim(), category: form.category.trim() || 'General', contactPerson: form.contactPerson,
        phone: form.phone, email: form.email, address: form.address, tin: form.tin,
        philgepsNo: form.philgepsNo || undefined,
        rating: Math.min(5, Math.max(1, Number(form.rating) || 4)), active: true, preferredOffices: ['MHO', 'TVS', 'MAYOR'] as OfficeCode[],
      };
      setState((s) => ({ ...s, vendors: [...s.vendors, v] }));
    }
    setForm(blank());
  };

  const startEdit = (v: Vendor) => {
    setEditing(v);
    setForm({ name: v.name, category: v.category, contactPerson: v.contactPerson, phone: v.phone, email: v.email, address: v.address, tin: v.tin, philgepsNo: v.philgepsNo ?? '', rating: String(v.rating) });
  };

  const toggle = (id: string) => setState((s) => ({ ...s, vendors: s.vendors.map((v) => (v.id === id ? { ...v, active: !v.active } : v)) }));
  const remove = (id: string) => {
    const hasRecords = state.billings.some((b) => b.vendorId === id) || state.vouchers.some((v) => v.payeeVendorId === id);
    if (!confirm(hasRecords ? 'This vendor has billing/voucher history (kept for audit). Remove the vendor profile anyway?' : 'Remove this vendor?')) return;
    setState((s) => ({ ...s, vendors: s.vendors.filter((v) => v.id !== id) }));
  };

  return (
    <div className="grid" style={{ gap: 14 }}>
      {!isAdmin && <div className="alert">👁️ View-only mode — only the administrator can register, edit or remove vendors.</div>}
      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div><h3>🏷️ Vendor Information Management</h3><p className="sub">{state.vendors.length} encoded businesses · AI spend forecast per vendor</p></div>
          <div className="row">
            <input placeholder="Search vendor…" value={q} onChange={(e) => setQ(e.target.value)} style={{ width: 200 }} />
            <select value={cat} onChange={(e) => setCat(e.target.value)} style={{ width: 180 }}>{cats.map((c) => <option key={c} value={c}>{c === 'ALL' ? 'All categories' : c}</option>)}</select>
          </div>
        </div>
        {state.vendors.length === 0 ? (
          <div className="empty">{isAdmin ? 'No vendors encoded yet. Register the first business using the form below.' : 'No vendors encoded yet. Records will appear here once the administrator registers them.'}</div>
        ) : list.length === 0 ? (
          <div className="empty">No vendors match this search/filter.</div>
        ) : (
        <table className="tbl">
          <thead><tr><th>Vendor</th><th>Category / TIN</th><th>Total billed (all yrs)</th><th>AI 12-mo forecast</th><th>Status</th>{isAdmin && <th>Actions</th>}</tr></thead>
          <tbody>
            {list.map((v) => {
              const billed = state.billings.filter((b) => b.vendorId === v.id).reduce((a, b) => a + b.amountBilled, 0);
              const f = forecastVendor(state.billings, v.id);
              return (
                <tr key={v.id}>
                  <td><strong>{v.name}</strong><br /><span style={{ fontSize: 12, color: '#64748b' }}>{v.contactPerson} · {v.phone}<br />{v.address}</span></td>
                  <td style={{ fontSize: 12 }}><span className="pill vio">{v.category}</span><br />TIN: {v.tin || '—'}<br />⭐ {v.rating.toFixed(1)}</td>
                  <td><strong>{peso0(billed)}</strong><br /><span style={{ fontSize: 11, color: '#64748b' }}>{state.billings.filter((b) => b.vendorId === v.id).length} billings</span></td>
                  <td><strong>{peso0(f.annualForecast)}</strong><br /><span style={{ fontSize: 11, color: '#64748b' }}>{f.historyMonths === 0 ? 'no history yet' : `${f.trendDirection} · ${f.confidence}% conf.`}</span></td>
                  <td>{v.active ? <span className="pill ok">Active</span> : <span className="pill bad">Inactive</span>}</td>
                  {isAdmin && (
                  <td><div className="row">
                    <button className="btn small ghost" onClick={() => startEdit(v)}>Edit</button>
                    <button className="btn small ghost" onClick={() => toggle(v.id)}>{v.active ? 'Deactivate' : 'Activate'}</button>
                    <button className="btn small danger" onClick={() => remove(v.id)}>Remove</button>
                  </div></td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
        )}
      </div>
      {isAdmin && (
      <div className="card">
        <h3>{editing ? 'Edit vendor / business' : '＋ Register new vendor / business'}</h3>
        <form className="grid2" onSubmit={save}>
          <label className="f">Business name<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Palo Construction Supply" /></label>
          <label className="f">Category<input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="e.g. Construction, Catering, Medical Supplies" /></label>
          <label className="f">Contact person<input value={form.contactPerson} onChange={(e) => setForm({ ...form, contactPerson: e.target.value })} /></label>
          <label className="f">Phone<input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></label>
          <label className="f">Email<input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label>
          <label className="f">TIN<input value={form.tin} onChange={(e) => setForm({ ...form, tin: e.target.value })} /></label>
          <label className="f">PhilGEPS no. (optional)<input value={form.philgepsNo} onChange={(e) => setForm({ ...form, philgepsNo: e.target.value })} /></label>
          <label className="f">Rating (1-5)<input type="number" min={1} max={5} step={0.1} value={form.rating} onChange={(e) => setForm({ ...form, rating: e.target.value })} /></label>
          <label className="f" style={{ gridColumn: '1 / -1' }}>Address<input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></label>
          <div className="row"><button className="btn primary" type="submit">{editing ? 'Save changes' : 'Register vendor'}</button>{editing && <button type="button" className="btn ghost" onClick={() => { setEditing(null); setForm(blank()); }}>Cancel</button>}</div>
        </form>
      </div>
      )}
    </div>
  );
}
