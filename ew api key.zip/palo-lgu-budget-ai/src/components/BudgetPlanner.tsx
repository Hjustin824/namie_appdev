import { useState } from 'react';
import { useStore } from '../lib/store';
import { OFFICES, type ActivityProject, type OfficeCode, type ProjectStatus } from '../types';
import { peso0, todayISO, uid } from '../lib/utils';

const CATS = ['Training Program', 'Health Program', 'Infrastructure', 'Capital Outlay', 'Socio-Cultural Event', 'Disaster Response', 'Livelihood', 'Maintenance'];

const blank = () => ({ title: '', office: 'TVS' as OfficeCode, category: CATS[0], description: '', startDate: todayISO(), endDate: todayISO(), proposedAmount: '', approvedAmount: '', status: 'Proposed' as ProjectStatus });

export default function BudgetPlanner() {
  const { state, setState, isAdmin } = useStore();
  const [officeFilter, setOfficeFilter] = useState<string>('ALL');
  const [editing, setEditing] = useState<ActivityProject | null>(null);
  const [form, setForm] = useState(blank());
  // Viewers get a local FY filter so merely browsing never writes to the database.
  const [localFY, setLocalFY] = useState(state.fiscalYear);

  const fy = isAdmin ? state.fiscalYear : localFY;
  const setFy = (y: number) => {
    if (isAdmin) setState((s) => ({ ...s, fiscalYear: y }));
    else setLocalFY(y);
  };

  const list = state.activities
    .filter((a) => a.fiscalYear === fy)
    .filter((a) => (officeFilter === 'ALL' ? true : a.office === officeFilter));

  const totals = list.reduce((acc, a) => ({ p: acc.p + a.proposedAmount, ap: acc.ap + a.approvedAmount, ob: acc.ob + a.obligatedAmount }), { p: 0, ap: 0, ob: 0 });

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) {
      alert('Title is required.');
      return;
    }
    if (editing) {
      setState((s) => ({ ...s, activities: s.activities.map((a) => (a.id === editing.id ? { ...editing, ...form, title: form.title.trim(), office: form.office, category: form.category, status: form.status, proposedAmount: Number(form.proposedAmount) || 0, approvedAmount: Number(form.approvedAmount) || editing.approvedAmount } : a)) }));
      setEditing(null);
    } else {
      setState((s) => ({
        ...s,
        activities: [...s.activities, {
          id: uid('a'), title: form.title.trim(), office: form.office, fiscalYear: fy, category: form.category,
          description: form.description, startDate: form.startDate, endDate: form.endDate,
          proposedAmount: Number(form.proposedAmount) || 0, approvedAmount: Number(form.approvedAmount) || 0,
          obligatedAmount: 0, status: form.status,
        }],
      }));
    }
    setForm(blank());
  };

  const startEdit = (a: ActivityProject) => {
    setEditing(a);
    setForm({ title: a.title, office: a.office, category: a.category, description: a.description, startDate: a.startDate, endDate: a.endDate, proposedAmount: String(a.proposedAmount), approvedAmount: String(a.approvedAmount), status: a.status });
  };

  const approve = (id: string) => {
    setState((s) => ({ ...s, activities: s.activities.map((a) => (a.id === id ? { ...a, status: 'Approved', approvedAmount: a.approvedAmount || a.proposedAmount } : a)) }));
  };

  const remove = (id: string) => {
    const a = state.activities.find((x) => x.id === id);
    if (a && a.obligatedAmount > 0 && !confirm(`This activity has ${peso0(a.obligatedAmount)} obligated via vouchers. Delete anyway? (Linked vouchers are kept.)`)) return;
    if (!a || a.obligatedAmount <= 0) {
      if (!confirm('Delete this activity/project?')) return;
    }
    setState((s) => ({ ...s, activities: s.activities.filter((x) => x.id !== id) }));
  };

  return (
    <div className="grid" style={{ gap: 14 }}>
      {!isAdmin && <div className="alert">👁️ View-only mode — only the administrator can add, edit, approve or delete budget items.</div>}
      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div>
            <h3>📋 Annual Budget Preparation — FY {fy}</h3>
            <p className="sub">LGU activities & projects per office. Proposed → Approved → Obligated (vouchered).</p>
          </div>
          <div className="row">
            <select value={fy} onChange={(e) => setFy(Number(e.target.value))} style={{ width: 110 }}>
              {[2024, 2025, 2026, 2027, 2028].map((y) => <option key={y} value={y}>FY {y}</option>)}
            </select>
            <select value={officeFilter} onChange={(e) => setOfficeFilter(e.target.value)} style={{ width: 190 }}>
              <option value="ALL">All offices</option>
              {OFFICES.map((o) => <option key={o.code} value={o.code}>{o.name}</option>)}
            </select>
          </div>
        </div>
        <div className="grid g3" style={{ margin: '10px 0' }}>
          <div className="card" style={{ background: '#f8fafc' }}><div className="l" style={{ fontSize: 12, color: '#64748b' }}>Total Proposed</div><div style={{ fontSize: 20, fontWeight: 800 }}>{peso0(totals.p)}</div></div>
          <div className="card" style={{ background: '#eff6ff' }}><div className="l" style={{ fontSize: 12, color: '#64748b' }}>Total Approved</div><div style={{ fontSize: 20, fontWeight: 800 }}>{peso0(totals.ap)}</div></div>
          <div className="card" style={{ background: '#ecfdf5' }}><div className="l" style={{ fontSize: 12, color: '#64748b' }}>Obligated / Balance</div><div style={{ fontSize: 20, fontWeight: 800 }}>{peso0(totals.ob)} <span style={{ fontSize: 12 }}>bal {peso0(totals.ap - totals.ob)}</span></div></div>
        </div>
        {list.length === 0 ? (
          <div className="empty">{isAdmin ? `No activities for FY ${fy} + this filter. Add the first one using the form below.` : `No activities encoded for FY ${fy} + this filter yet.`}</div>
        ) : (
        <table className="tbl">
          <thead><tr><th>Activity / Project</th><th>Office</th><th>Amounts</th><th>Status</th>{isAdmin && <th>Actions</th>}</tr></thead>
          <tbody>
            {list.map((a) => (
              <tr key={a.id}>
                <td><strong>{a.title}</strong><br /><span style={{ fontSize: 12, color: '#64748b' }}>{a.category} · {a.startDate} → {a.endDate}</span><br /><span style={{ fontSize: 12 }}>{a.description}</span></td>
                <td><span className="pill info">{a.office}</span></td>
                <td style={{ fontSize: 12 }}>Prop: {peso0(a.proposedAmount)}<br />Appr: <strong>{peso0(a.approvedAmount)}</strong><br />Obl: {peso0(a.obligatedAmount)}</td>
                <td><span className={`pill ${a.status === 'Completed' ? 'ok' : a.status === 'Ongoing' || a.status === 'Approved' ? 'info' : a.status === 'Deferred' ? 'bad' : 'warn'}`}>{a.status}</span></td>
                {isAdmin && (
                <td><div className="row">
                  <button className="btn small ghost" onClick={() => startEdit(a)}>Edit</button>
                  {a.status === 'Proposed' && <button className="btn small primary" onClick={() => approve(a.id)}>Approve</button>}
                  <button className="btn small danger" onClick={() => remove(a.id)}>Delete</button>
                </div></td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
        )}
      </div>
      {isAdmin && (
      <div className="card">
        <h3>{editing ? 'Edit activity/project' : '＋ New activity / project (FY ' + fy + ')'}</h3>
        <form className="grid2" onSubmit={save}>
          <label className="f" style={{ gridColumn: '1 / -1' }}>Title<input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Feeding Program — Brgy. San Joaquin" /></label>
          <label className="f">Office<select value={form.office} onChange={(e) => setForm({ ...form, office: e.target.value as OfficeCode })}>{OFFICES.map((o) => <option key={o.code} value={o.code}>{o.name}</option>)}</select></label>
          <label className="f">Category<select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{CATS.map((c) => <option key={c}>{c}</option>)}</select></label>
          <label className="f" style={{ gridColumn: '1 / -1' }}>Description<textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} /></label>
          <label className="f">Start<input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} /></label>
          <label className="f">End<input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} /></label>
          <label className="f">Proposed amount (₱)<input type="number" min={0} value={form.proposedAmount} onChange={(e) => setForm({ ...form, proposedAmount: e.target.value })} placeholder="0" /></label>
          <label className="f">Approved amount (₱)<input type="number" min={0} value={form.approvedAmount} onChange={(e) => setForm({ ...form, approvedAmount: e.target.value })} placeholder="0" /></label>
          <label className="f">Status<select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as ProjectStatus })}>{(['Proposed', 'Approved', 'Ongoing', 'Completed', 'Deferred'] as ProjectStatus[]).map((s) => <option key={s}>{s}</option>)}</select></label>
          <div className="row"><button className="btn primary" type="submit">{editing ? 'Save changes' : 'Add to annual budget'}</button>{editing && <button type="button" className="btn ghost" onClick={() => { setEditing(null); setForm(blank()); }}>Cancel</button>}</div>
        </form>
      </div>
      )}
    </div>
  );
}
