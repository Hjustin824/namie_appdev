import { useMemo, useState } from 'react';
import { useStore } from '../lib/store';
import { OFFICES, type Billing, type BillingStatus, type OfficeCode } from '../types';
import { downloadCSV, monthName, peso0, toCSV, uid } from '../lib/utils';
import { Bars } from './Charts';

const blankBill = (fy: number) => ({
  vendorId: '', office: 'MHO' as OfficeCode, activityId: '',
  year: String(fy), month: String(new Date().getMonth() + 1),
  billed: '', paid: '', dueDate: '', orNo: '', status: 'Billed' as BillingStatus,
});

export default function Reports() {
  const { state, setState, isAdmin } = useStore();
  const [year, setYear] = useState(state.fiscalYear);
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [office, setOffice] = useState('ALL');
  const [mode, setMode] = useState<'Monthly' | 'Annual'>('Monthly');
  const [editingBill, setEditingBill] = useState<Billing | null>(null);
  const [bform, setBform] = useState(() => blankBill(state.fiscalYear));

  const years = useMemo(() => {
    const ys = Array.from(new Set(state.billings.map((b) => b.year)));
    if (!ys.includes(state.fiscalYear)) ys.push(state.fiscalYear);
    if (!ys.includes(year)) ys.push(year);
    return ys.sort((a, b) => a - b);
  }, [state.billings, state.fiscalYear, year]);

  const monthlyRows = state.billings.filter((b) => b.year === year && b.month === month && (office === 'ALL' || b.office === office));
  const annualRows = state.billings.filter((b) => b.year === year && (office === 'ALL' || b.office === office));

  const agg = (rows: typeof annualRows) => {
    const m = new Map<string, { vendor: string; office: string; billed: number; paid: number }>();
    for (const r of rows) {
      const v = state.vendors.find((x) => x.id === r.vendorId);
      const key = r.vendorId;
      const cur = m.get(key) ?? { vendor: v?.name ?? '(vendor removed)', office: '', billed: 0, paid: 0 };
      cur.billed += r.amountBilled;
      cur.paid += r.amountPaid;
      cur.office = office === 'ALL' ? 'All offices' : OFFICES.find((o) => o.code === r.office)?.short ?? r.office;
      m.set(key, cur);
    }
    return [...m.values()].sort((a, b) => b.billed - a.billed);
  };

  const monthlyAgg = agg(monthlyRows);
  const annualAgg = agg(annualRows);
  const shown = mode === 'Monthly' ? monthlyAgg : annualAgg;

  const totalBilled = shown.reduce((a, b) => a + b.billed, 0);
  const totalPaid = shown.reduce((a, b) => a + b.paid, 0);

  const annualMonthly = Array.from({ length: 12 }, (_, i) => ({
    label: monthName(i + 1).slice(0, 3),
    value: annualRows.filter((r) => r.month === i + 1).reduce((a, b) => a + b.amountBilled, 0),
  }));

  const exportCSV = () => {
    const csv = toCSV(shown.map((r) => ({
      Report: mode, Year: year, Month: mode === 'Monthly' ? monthName(month) : 'FULL-YEAR',
      Office: office, Vendor: r.vendor, Billed_PHP: r.billed, Paid_PHP: r.paid, Balance_PHP: r.billed - r.paid,
    })));
    downloadCSV(`palo-lgu-${mode.toLowerCase()}-vendor-report-${year}${mode === 'Monthly' ? '-' + String(month).padStart(2, '0') : ''}.csv`, csv);
  };

  // ---- Billing records CRUD (admin) ----
  const saveBill = (e: React.FormEvent) => {
    e.preventDefault();
    const billed = Number(bform.billed) || 0;
    const paid = Number(bform.paid) || 0;
    if (!bform.vendorId) { alert('Select a vendor.'); return; }
    if (billed <= 0) { alert('Billed amount must be greater than zero.'); return; }
    const y = Number(bform.year) || state.fiscalYear;
    const m = Math.min(12, Math.max(1, Number(bform.month) || 1));
    const due = bform.dueDate || `${y}-${String(m).padStart(2, '0')}-28`;
    if (editingBill) {
      setState((s) => ({
        ...s,
        billings: s.billings.map((b) => (b.id === editingBill.id ? { ...b, vendorId: bform.vendorId, office: bform.office, activityId: bform.activityId, year: y, month: m, amountBilled: billed, amountPaid: Math.min(paid, billed), dueDate: due, status: bform.status, orNo: bform.orNo || undefined } : b)),
      }));
      setEditingBill(null);
    } else {
      setState((s) => ({
        ...s,
        billings: [...s.billings, { id: uid('bl'), vendorId: bform.vendorId, office: bform.office, activityId: bform.activityId, year: y, month: m, amountBilled: billed, amountPaid: Math.min(paid, billed), dueDate: due, status: bform.status, orNo: bform.orNo || undefined }],
      }));
    }
    setBform(blankBill(state.fiscalYear));
  };

  const startEditBill = (b: Billing) => {
    setEditingBill(b);
    setBform({ vendorId: b.vendorId, office: b.office, activityId: b.activityId, year: String(b.year), month: String(b.month), billed: String(b.amountBilled), paid: String(b.amountPaid), dueDate: b.dueDate, orNo: b.orNo ?? '', status: b.status });
  };

  const removeBill = (id: string) => {
    if (!confirm('Delete this billing record? Report totals will update automatically.')) return;
    setState((s) => ({ ...s, billings: s.billings.filter((b) => b.id !== id) }));
  };

  const records = [...state.billings].sort((a, b) => b.year - a.year || b.month - a.month);
  const vendorName = (id: string) => state.vendors.find((v) => v.id === id)?.name ?? '(vendor removed)';

  return (
    <div className="grid" style={{ gap: 14 }}>
      {!isAdmin && <div className="alert">👁️ View-only mode — reports update automatically from admin-encoded records. You may still export and print.</div>}
      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div>
            <h3>📊 {mode} Vendor Billing Report — {mode === 'Monthly' ? `${monthName(month)} ` : ''}{year}</h3>
            <p className="sub">Per-vendor billed vs paid, balances and collection status. Exportable for COA / SB submission.</p>
          </div>
          <div className="row no-print">
            <select value={mode} onChange={(e) => setMode(e.target.value as 'Monthly' | 'Annual')} style={{ width: 130 }}>
              <option>Monthly</option><option>Annual</option>
            </select>
            <select value={year} onChange={(e) => setYear(Number(e.target.value))} style={{ width: 100 }}>
              {years.map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
            {mode === 'Monthly' && (
              <select value={month} onChange={(e) => setMonth(Number(e.target.value))} style={{ width: 130 }}>
                {Array.from({ length: 12 }, (_, i) => <option key={i + 1} value={i + 1}>{monthName(i + 1)}</option>)}
              </select>
            )}
            <select value={office} onChange={(e) => setOffice(e.target.value)} style={{ width: 170 }}>
              <option value="ALL">All offices</option>
              {OFFICES.map((o) => <option key={o.code} value={o.code}>{o.short}</option>)}
            </select>
            <button className="btn ghost small" onClick={exportCSV}>⬇ Export CSV</button>
            <button className="btn dark small" onClick={() => window.print()}>🖨 Print</button>
          </div>
        </div>
        <div className="grid g3" style={{ margin: '10px 0' }}>
          <div className="card" style={{ background: '#eff6ff' }}><div style={{ fontSize: 12, color: '#64748b' }}>Total billed</div><div style={{ fontSize: 22, fontWeight: 800 }}>{peso0(totalBilled)}</div></div>
          <div className="card" style={{ background: '#ecfdf5' }}><div style={{ fontSize: 12, color: '#64748b' }}>Total paid</div><div style={{ fontSize: 22, fontWeight: 800 }}>{peso0(totalPaid)}</div></div>
          <div className="card" style={{ background: '#fef3c7' }}><div style={{ fontSize: 12, color: '#64748b' }}>Outstanding balance</div><div style={{ fontSize: 22, fontWeight: 800 }}>{peso0(totalBilled - totalPaid)}</div></div>
        </div>
        {mode === 'Annual' && (<><h3 style={{ fontSize: 13 }}>Monthly trend — {year}</h3><Bars data={annualMonthly} color="#059669" /></>)}
        {shown.length === 0 ? (
          <div className="empty">{isAdmin ? 'No billings for this period/filter. Encode billing records using the form below.' : 'No billings for this period/filter yet.'}</div>
        ) : (
        <table className="tbl" style={{ marginTop: 10 }}>
          <thead><tr><th>Vendor</th><th>Billed</th><th>Paid</th><th>Balance</th><th>Status</th></tr></thead>
          <tbody>
            {shown.map((r) => {
              const bal = r.billed - r.paid;
              return (
                <tr key={r.vendor}>
                  <td><strong>{r.vendor}</strong><br /><span style={{ fontSize: 11, color: '#64748b' }}>{r.office}</span></td>
                  <td>{peso0(r.billed)}</td>
                  <td>{peso0(r.paid)}</td>
                  <td style={{ fontWeight: 800 }}>{peso0(bal)}</td>
                  <td>{bal <= 0 ? <span className="pill ok">Paid</span> : bal < r.billed ? <span className="pill warn">Partial</span> : <span className="pill bad">Unpaid</span>}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        )}
        <p style={{ fontSize: 11, color: '#64748b' }}>Municipality of Palo, Leyte · Generated {new Date().toLocaleDateString()} · Amounts in Philippine Peso</p>
      </div>

      {isAdmin && (
      <div className="card">
        <h3>🧾 Billing Records — encode / edit / delete</h3>
        <p className="sub">Every record encoded here automatically appears in the reports above, on the dashboard, and in the AI forecast. ({records.length} records)</p>
        {state.vendors.length === 0 ? (
          <div className="empty">Register at least one vendor/business first (see Vendors tab).</div>
        ) : (
        <form className="grid2" onSubmit={saveBill}>
          <label className="f">Vendor<select value={bform.vendorId} onChange={(e) => setBform({ ...bform, vendorId: e.target.value })}><option value="">— Select vendor —</option>{state.vendors.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}</select></label>
          <label className="f">Office<select value={bform.office} onChange={(e) => setBform({ ...bform, office: e.target.value as OfficeCode })}>{OFFICES.map((o) => <option key={o.code} value={o.code}>{o.name}</option>)}</select></label>
          <label className="f">Activity (optional)<select value={bform.activityId} onChange={(e) => setBform({ ...bform, activityId: e.target.value })}><option value="">— None —</option>{state.activities.map((a) => <option key={a.id} value={a.id}>{a.title}</option>)}</select></label>
          <label className="f">Status<select value={bform.status} onChange={(e) => setBform({ ...bform, status: e.target.value as BillingStatus })}>{(['Billed', 'Partial', 'Paid', 'Overdue'] as BillingStatus[]).map((s) => <option key={s}>{s}</option>)}</select></label>
          <label className="f">Year<input type="number" value={bform.year} onChange={(e) => setBform({ ...bform, year: e.target.value })} /></label>
          <label className="f">Month (1-12)<input type="number" min={1} max={12} value={bform.month} onChange={(e) => setBform({ ...bform, month: e.target.value })} /></label>
          <label className="f">Amount billed (₱)<input type="number" min={0} value={bform.billed} onChange={(e) => setBform({ ...bform, billed: e.target.value })} placeholder="0" /></label>
          <label className="f">Amount paid (₱)<input type="number" min={0} value={bform.paid} onChange={(e) => setBform({ ...bform, paid: e.target.value })} placeholder="0" /></label>
          <label className="f">Due date<input type="date" value={bform.dueDate} onChange={(e) => setBform({ ...bform, dueDate: e.target.value })} /></label>
          <label className="f">O.R. no. (optional)<input value={bform.orNo} onChange={(e) => setBform({ ...bform, orNo: e.target.value })} placeholder="OR-…" /></label>
          <div className="row" style={{ gridColumn: '1 / -1' }}>
            <button className="btn primary" type="submit">{editingBill ? 'Save changes' : '＋ Encode billing record'}</button>
            {editingBill && <button type="button" className="btn ghost" onClick={() => { setEditingBill(null); setBform(blankBill(state.fiscalYear)); }}>Cancel</button>}
          </div>
        </form>
        )}
        {records.length > 0 && (
        <table className="tbl" style={{ marginTop: 12 }}>
          <thead><tr><th>Period</th><th>Vendor / Office</th><th>Billed / Paid</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {records.map((b) => (
              <tr key={b.id}>
                <td><strong>{monthName(b.month).slice(0, 3)} {b.year}</strong><br /><span style={{ fontSize: 11, color: '#64748b' }}>due {b.dueDate}{b.orNo ? ` · ${b.orNo}` : ''}</span></td>
                <td><strong>{vendorName(b.vendorId)}</strong><br /><span style={{ fontSize: 11, color: '#64748b' }}>{b.office}</span></td>
                <td>{peso0(b.amountBilled)} / {peso0(b.amountPaid)}</td>
                <td><span className="pill info">{b.status}</span></td>
                <td><div className="row">
                  <button className="btn small ghost" onClick={() => startEditBill(b)}>Edit</button>
                  <button className="btn small danger" onClick={() => removeBill(b.id)}>Delete</button>
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
        )}
      </div>
      )}
    </div>
  );
}
