import { useStore } from '../lib/store';
import { OFFICES } from '../types';
import { peso0 } from '../lib/utils';
import { forecastVendor } from '../lib/forecast';
import { Bars } from './Charts';
import { upcomingEvents } from './EventsSection';

export default function Dashboard({ go }: { go: (tab: string) => void }) {
  const { state, isAdmin } = useStore();
  const { accounts, activities, vendors, vouchers, billings, fiscalYear } = state;
  const nextEvents = upcomingEvents(state.events ?? []).slice(0, 3);

  const totalBank = accounts.reduce((a, b) => a + b.bankBalance, 0);
  const totalLedger = accounts.reduce((a, b) => a + b.ledgerBalance, 0);
  const variance = totalBank - totalLedger;
  const unverified = accounts.filter((a) => !a.verified).length;

  const fyActs = activities.filter((a) => a.fiscalYear === fiscalYear);
  const approved = fyActs.reduce((a, b) => a + b.approvedAmount, 0);
  const obligated = fyActs.reduce((a, b) => a + b.obligatedAmount, 0);
  const utilization = approved ? (obligated / approved) * 100 : 0;

  const fyBilled = billings.filter((b) => b.year === fiscalYear).reduce((a, b) => a + b.amountBilled, 0);
  const fyPaid = billings.filter((b) => b.year === fiscalYear).reduce((a, b) => a + b.amountPaid, 0);
  const pendingVouchers = vouchers.filter((v) => v.status === 'Pending' || v.status === 'Approved').length;

  const topForecasts = vendors
    .map((v) => ({ v, f: forecastVendor(billings, v.id) }))
    .sort((a, b) => b.f.annualForecast - a.f.annualForecast)
    .slice(0, 3);

  const monthlyFY = Array.from({ length: 12 }, (_, i) => {
    const m = i + 1;
    const val = billings.filter((b) => b.year === fiscalYear && b.month === m).reduce((a, b) => a + b.amountBilled, 0);
    return { label: ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'][i], value: val };
  });

  const isEmpty = accounts.length === 0 && activities.length === 0 && vendors.length === 0 && vouchers.length === 0 && billings.length === 0;

  return (
    <div className="grid" style={{ gap: 14 }}>
      {isEmpty && (
        <div className="card" style={{ background: '#eff6ff', borderColor: '#bfdbfe' }}>
          <h3>👋 Welcome — the system starts empty</h3>
          <p className="sub">
            {isAdmin
              ? 'No records have been encoded yet. As administrator, start by adding bank accounts, then annual budget activities, then vendors/businesses. Every figure you encode appears here automatically.'
              : 'No records have been encoded yet. Figures will appear here automatically once the administrator adds them.'}
          </p>
          {isAdmin && (
            <div className="row">
              <button className="btn primary small" onClick={() => go('bank')}>＋ Add bank accounts</button>
              <button className="btn dark small" onClick={() => go('budget')}>＋ Add budget activities</button>
              <button className="btn ghost small" onClick={() => go('vendors')}>＋ Register vendors</button>
            </div>
          )}
        </div>
      )}

      <div className="grid g4">
        <div className="card kpi">
          <div className="l">Total Bank Balance</div>
          <div className="v">{peso0(totalBank)}</div>
          <div>
            {accounts.length === 0 ? (
              <span className="pill info">No accounts yet</span>
            ) : (
              <span className={`pill ${variance === 0 ? 'ok' : 'bad'}`}>{variance === 0 ? '✓ Reconciled' : `Variance ₱${Math.abs(variance).toLocaleString()}`}</span>
            )}
          </div>
        </div>
        <div className="card kpi">
          <div className="l">FY {fiscalYear} Approved Budget</div>
          <div className="v">{peso0(approved)}</div>
          <div className="l">{fyActs.length} activities/projects across 3 offices</div>
        </div>
        <div className="card kpi">
          <div className="l">Budget Utilization</div>
          <div className="v">{utilization.toFixed(1)}%</div>
          <div className="l">{peso0(obligated)} obligated of {peso0(approved)}</div>
        </div>
        <div className="card kpi">
          <div className="l">Vendor Payables FY {fiscalYear}</div>
          <div className="v">{peso0(fyBilled - fyPaid)}</div>
          <div><span className="pill warn">{pendingVouchers} vouchers in pipeline</span></div>
        </div>
      </div>

      {unverified > 0 && isAdmin && (
        <div className="alert bad">
          ⚠️ {unverified} bank account(s) have unverified balances / variances. <button className="btn small danger" onClick={() => go('bank')}>Verify now</button>
        </div>
      )}

      <div className="grid g2">
        <div className="card">
          <h3>Monthly vendor billings — FY {fiscalYear}</h3>
          <p className="sub">Actual billed amounts per month, all offices combined.</p>
          <Bars data={monthlyFY} color="#1d4ed8" />
        </div>
        <div className="card">
          <h3>Budget per office — FY {fiscalYear}</h3>
          <p className="sub">Approved vs obligated per frontline office.</p>
          <table className="tbl">
            <thead><tr><th>Office</th><th>Approved</th><th>Obligated</th><th>Util.</th></tr></thead>
            <tbody>
              {OFFICES.map((o) => {
                const acts = fyActs.filter((a) => a.office === o.code);
                const ap = acts.reduce((a, b) => a + b.approvedAmount, 0);
                const ob = acts.reduce((a, b) => a + b.obligatedAmount, 0);
                const u = ap ? (ob / ap) * 100 : 0;
                return (
                  <tr key={o.code}>
                    <td><strong>{o.short}</strong><br /><span style={{ color: '#64748b', fontSize: 11 }}>{acts.length} activities</span></td>
                    <td>{peso0(ap)}</td>
                    <td>{peso0(ob)}</td>
                    <td><span className={`pill ${u > 90 ? 'bad' : u > 70 ? 'warn' : 'ok'}`}>{u.toFixed(0)}%</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {isAdmin && (
          <div className="row" style={{ marginTop: 10 }}>
            <button className="btn ghost small" onClick={() => go('budget')}>Open annual budget →</button>
          </div>
          )}
        </div>
      </div>

      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div>
            <h3>📅 Upcoming municipal events</h3>
            <p className="sub">Posted by the admin — visible to all viewers.</p>
          </div>
          <button className="btn ghost small" onClick={() => go('events')}>View all events →</button>
        </div>
        {nextEvents.length === 0 ? (
          <div className="empty">{isAdmin ? 'No upcoming events. Post one from the Events tab.' : 'No upcoming events posted yet. Please check back soon!'}</div>
        ) : (
          <div className="grid g3">
            {nextEvents.map((ev) => (
              <div key={ev.id} className="card" style={{ background: '#f8fafc' }}>
                <span className={`pill ${ev.status === 'Ongoing' ? 'ok' : 'info'}`}>{ev.status}</span>
                <div style={{ fontSize: 15, fontWeight: 800, margin: '8px 0 2px' }}>{ev.title}</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#1d4ed8' }}>
                  📆 {ev.date}{ev.time ? ` · 🕘 ${ev.time}` : ''}
                </div>
                {ev.venue && <div style={{ fontSize: 12, color: '#475569' }}>📍 {ev.venue}</div>}
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="card">
        <h3>🤖 AI Vendor Forecast — top spend (next 12 months)</h3>
        <p className="sub">Hybrid OLS-trend + weighted moving average + seasonal index, computed from encoded billing history.</p>
        {topForecasts.length === 0 ? (
          <div className="empty">No vendor billing history yet — forecasts generate automatically once billings are encoded.</div>
        ) : (
        <div className="grid g3">
          {topForecasts.map(({ v, f }) => (
            <div key={v.id} className="card" style={{ background: '#f8fafc' }}>
              <strong>{v.name}</strong>
              <div style={{ fontSize: 12, color: '#64748b' }}>{v.category} · {f.historyMonths === 0 ? 'no history' : `${f.trendDirection} trend · ${f.confidence}% confidence`}</div>
              <div style={{ fontSize: 20, fontWeight: 800, margin: '6px 0' }}>{peso0(f.annualForecast)} <span style={{ fontSize: 11, color: '#64748b' }}>/ yr forecast</span></div>
              <div><span className={`pill ${f.riskLevel === 'Low' ? 'ok' : f.riskLevel === 'Medium' ? 'warn' : 'bad'}`}>{f.riskLevel} risk</span></div>
            </div>
          ))}
        </div>
        )}
        {isAdmin && (
        <div className="row" style={{ marginTop: 10 }}>
          <button className="btn dark small" onClick={() => go('forecast')}>Open AI forecasting engine →</button>
          <button className="btn ghost small" onClick={() => go('vouchers')}>Generate voucher →</button>
        </div>
        )}
      </div>
    </div>
  );
}
