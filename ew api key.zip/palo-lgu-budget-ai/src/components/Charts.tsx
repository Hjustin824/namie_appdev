import type { Billing } from '../types';
import { monthLabel } from '../lib/forecast';

export function Bars({ data, color = '#1d4ed8', forecastFrom }: { data: { label: string; value: number }[]; color?: string; forecastFrom?: number }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div>
      <div className="bars">
        {data.map((d, i) => (
          <div
            key={i}
            className="bar"
            title={`${d.label}: ₱${d.value.toLocaleString()}`}
            style={{
              height: `${Math.max(4, (d.value / max) * 100)}%`,
              background: forecastFrom !== undefined && i >= forecastFrom ? 'repeating-linear-gradient(45deg,#93c5fd,#93c5fd 4px,#dbeafe 4px,#dbeafe 8px)' : color,
              opacity: forecastFrom !== undefined && i >= forecastFrom ? 0.95 : 1,
            }}
          >
            <span>{d.value >= max * 0.35 ? `₱${Math.round(d.value / 1000)}k` : ''}</span>
          </div>
        ))}
      </div>
      <div className="bar-legend">
        {data.map((d, i) => (
          <div key={i}>{d.label}</div>
        ))}
      </div>
    </div>
  );
}

export function historyPlusForecast(billings: Billing[], vendorId: string, forecast: { year: number; month: number; amount: number }[]): { label: string; value: number }[] {
  const map = new Map<string, number>();
  for (const b of billings) {
    if (b.vendorId !== vendorId) continue;
    const k = `${b.year}-${b.month}`;
    map.set(k, (map.get(k) ?? 0) + b.amountBilled);
  }
  const hist = [...map.entries()]
    .map(([k, v]) => {
      const [y, m] = k.split('-').map(Number);
      return { y, m, v };
    })
    .sort((a, b) => a.y - b.y || a.m - b.m)
    .slice(-8);
  const out = hist.map((h) => ({ label: monthLabel(h.y, h.m).split(' ')[0], value: h.v }));
  forecast.slice(0, 4).forEach((f) => out.push({ label: monthLabel(f.year, f.month).split(' ')[0] + '*', value: f.amount }));
  return out;
}
