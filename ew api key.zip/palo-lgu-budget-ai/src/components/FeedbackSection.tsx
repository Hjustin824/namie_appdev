import { useState } from 'react';
import { useStore } from '../lib/store';
import { OFFICES, type Feedback, type FeedbackStatus, type FeedbackType } from '../types';
import { uid } from '../lib/utils';
import { deleteFeedback, patchFeedback, postFeedback } from '../lib/api';

const TYPES: FeedbackType[] = ['Comment', 'Suggestion', 'Concern', 'Complaint'];
const STATUSES: FeedbackStatus[] = ['New', 'Reviewed', 'Resolved'];

function statusPill(s: FeedbackStatus): string {
  return s === 'Resolved' ? 'ok' : s === 'Reviewed' ? 'info' : 'warn';
}

export default function FeedbackSection() {
  const { state, setState, auth, isAdmin, refresh } = useStore();
  const [form, setForm] = useState({ type: 'Comment' as FeedbackType, office: '', subject: '', message: '' });
  const [sent, setSent] = useState(false);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [responses, setResponses] = useState<Record<string, string>>({});

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.subject.trim() || !form.message.trim()) {
      alert('Please enter both a subject and a message.');
      return;
    }
    const fb: Feedback = {
      id: uid('fb'),
      authorName: auth.name || 'Anonymous',
      authorRole: auth.role ?? 'viewer',
      type: form.type,
      office: form.office || undefined,
      subject: form.subject.trim(),
      message: form.message.trim(),
      status: 'New',
      createdAt: new Date().toISOString(),
    };
    // Optimistic local update (works offline), then push to shared server
    // so the admin receives it on their own device.
    setState((s) => ({ ...s, feedbacks: [fb, ...s.feedbacks] }));
    void postFeedback(fb).then((ok) => {
      if (ok) refresh();
    });
    setForm({ type: 'Comment', office: '', subject: '', message: '' });
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  const setStatus = (id: string, status: FeedbackStatus) => {
    setState((s) => ({ ...s, feedbacks: s.feedbacks.map((f) => (f.id === id ? { ...f, status } : f)) }));
    void patchFeedback(id, { status }).then(() => refresh());
  };

  const saveResponse = (id: string) => {
    const r = (responses[id] ?? '').trim();
    if (!r) return;
    setState((s) => ({ ...s, feedbacks: s.feedbacks.map((f) => (f.id === id ? { ...f, response: r, status: 'Reviewed' as FeedbackStatus } : f)) }));
    setResponses((p) => ({ ...p, [id]: '' }));
    void patchFeedback(id, { response: r, status: 'Reviewed' }).then(() => refresh());
  };

  const remove = (id: string) => {
    if (!confirm('Delete this feedback permanently?')) return;
    setState((s) => ({ ...s, feedbacks: s.feedbacks.filter((f) => f.id !== id) }));
    void deleteFeedback(id).then(() => refresh());
  };

  const visible = isAdmin
    ? state.feedbacks.filter(
        (f) => (statusFilter === 'ALL' || f.status === statusFilter) && (typeFilter === 'ALL' || f.type === typeFilter)
      )
    : state.feedbacks.filter((f) => f.authorName === auth.name);

  const newCount = state.feedbacks.filter((f) => f.status === 'New').length;

  return (
    <div className="grid" style={{ gap: 14 }}>
      {!isAdmin && (
      <div className="card">
        <h3>💬 Send Feedback, Suggestion or Concern</h3>
        <p className="sub">
          As a viewer you can only see the dashboard, but your voice matters — send comments, suggestions or concerns here. The admin reviews every message.
        </p>
        {sent && <div className="alert ok">✓ Your feedback was saved and sent to the administrator. Thank you!</div>}
        <form className="grid2" onSubmit={submit}>
          <label className="f">Type
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as FeedbackType })}>
              {TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </label>
          <label className="f">Related office (optional)
            <select value={form.office} onChange={(e) => setForm({ ...form, office: e.target.value })}>
              <option value="">— General / Not specific —</option>
              {OFFICES.map((o) => <option key={o.code} value={o.code}>{o.name}</option>)}
            </select>
          </label>
          <label className="f" style={{ gridColumn: '1 / -1' }}>Subject<input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="e.g. Request for medicine stock update" /></label>
          <label className="f" style={{ gridColumn: '1 / -1' }}>Message<textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} rows={4} placeholder="Write your comment, suggestion or concern in detail…" /></label>
          <div><button className="btn primary" type="submit">Send Feedback</button></div>
        </form>
      </div>
      )}

      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div>
            <h3>{isAdmin ? `📥 Feedback Inbox — Admin Review (${state.feedbacks.length})` : `📨 My Submitted Feedback (${visible.length})`}</h3>
            <p className="sub">{isAdmin ? 'Review, respond to, update the status of, or delete community feedback.' : 'Track the status of the messages you sent.'}</p>
          </div>
          {isAdmin && (
            <div className="row no-print">
              <button className="btn small ghost" onClick={refresh} title="Re-read the system database (picks up viewer messages sent from another tab)">
                ↻ Refresh inbox
              </button>
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} style={{ width: 140 }}>
                <option value="ALL">All statuses</option>
                {STATUSES.map((s) => <option key={s}>{s}</option>)}
              </select>
              <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} style={{ width: 140 }}>
                <option value="ALL">All types</option>
                {TYPES.map((t) => <option key={t}>{t}</option>)}
              </select>
            </div>
          )}
        </div>
        {isAdmin && newCount > 0 && <div className="alert">🔔 {newCount} unread (New) message{newCount > 1 ? 's' : ''} awaiting review.</div>}
        {visible.length === 0 && (
          <div className="empty">No feedback {isAdmin ? 'matching this filter yet' : 'submitted by you yet'}. {isAdmin ? 'Viewer messages will appear here automatically.' : 'Use the form above to send your first message.'}</div>
        )}
        <div className="grid" style={{ gap: 10 }}>
          {visible.map((f) => (
            <div key={f.id} className="card" style={{ background: '#f8fafc' }}>
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <div>
                  <strong>{f.subject}</strong>{' '}
                  <span className="pill vio">{f.type}</span>{' '}
                  <span className={`pill ${statusPill(f.status)}`}>{f.status}</span>
                </div>
                <span style={{ fontSize: 11, color: '#64748b' }}>{new Date(f.createdAt).toLocaleString()}</span>
              </div>
              <p style={{ fontSize: 13, margin: '8px 0' }}>{f.message}</p>
              <p style={{ fontSize: 11, color: '#64748b', margin: '0 0 8px' }}>
                From: <strong>{f.authorName}</strong> ({f.authorRole})
                {f.office ? ` · Re: ${OFFICES.find((o) => o.code === f.office)?.short ?? f.office}` : ''}
              </p>
              {f.response && <div className="alert ok">↩️ <strong>Admin response:</strong> {f.response}</div>}
              {isAdmin && (
                <div className="no-print">
                  <label className="f">Admin response<textarea value={responses[f.id] ?? f.response ?? ''} onChange={(e) => setResponses((p) => ({ ...p, [f.id]: e.target.value }))} rows={2} placeholder="Type an official response…" /></label>
                  <div className="row" style={{ marginTop: 8 }}>
                    <button className="btn small primary" onClick={() => saveResponse(f.id)}>Save response</button>
                    {STATUSES.map((s) => (
                      <button key={s} className="btn small ghost" disabled={f.status === s} onClick={() => setStatus(f.id, s)}>Mark {s}</button>
                    ))}
                    <button className="btn small danger" onClick={() => remove(f.id)}>Delete</button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
