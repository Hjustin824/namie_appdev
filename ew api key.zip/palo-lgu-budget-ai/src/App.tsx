import { useState } from 'react';
import { StoreProvider, useStore } from './lib/store';
import { clearState } from './lib/db';
import Dashboard from './components/Dashboard';
import BankVerification from './components/BankVerification';
import BudgetPlanner from './components/BudgetPlanner';
import VendorManager from './components/VendorManager';
import VoucherGenerator from './components/VoucherGenerator';
import Reports from './components/Reports';
import ForecastPanel from './components/ForecastPanel';
import FeedbackSection from './components/FeedbackSection';
import EventsSection from './components/EventsSection';
import Login from './components/Login';

const ALL_TABS = [
  { id: 'dashboard', label: '📊 Dashboard', desc: 'LGU-wide budget at a glance' },
  { id: 'events', label: '📅 Events', desc: 'Upcoming municipal events & announcements' },
  { id: 'bank', label: '🏦 Bank Verification', desc: 'Verify ledger vs bank balances' },
  { id: 'budget', label: '📋 Annual Budget', desc: 'Activities & projects per office' },
  { id: 'vendors', label: '🏷️ Vendors', desc: 'Business / supplier registry' },
  { id: 'vouchers', label: '🧾 Vouchers', desc: 'Disbursement vouchers & approvals' },
  { id: 'reports', label: '📊 Billing Reports', desc: 'Monthly & annual vendor reports' },
  { id: 'forecast', label: '🤖 AI Forecast', desc: 'Vendor forecasting algorithm' },
  { id: 'feedback', label: '💬 Feedback', desc: 'Comments, suggestions & concerns' },
];

function Shell() {
  const [tab, setTab] = useState('dashboard');
  const { state, clearAll, auth, isAdmin, connected, logout, changeAdminPass } = useStore();
  const [showPass, setShowPass] = useState(false);
  const [newPass, setNewPass] = useState('');
  // Viewers can see Dashboard (read-only) + Events (upcoming) + Feedback (to send messages).
  // Admins see everything; their Feedback tab is inbox-only (receive, not send).
  const TABS = isAdmin ? ALL_TABS : ALL_TABS.filter((t) => t.id === 'dashboard' || t.id === 'events' || t.id === 'feedback');
  const safeTab = TABS.some((t) => t.id === tab) ? tab : 'dashboard';
  const active = TABS.find((t) => t.id === safeTab)!;
  const newFb = state.feedbacks.filter((f) => f.status === 'New').length;

  if (!auth.role) return <Login />;

  const doClear = () => {
    if (!confirm('Delete ALL records (accounts, budgets, vendors, vouchers, billings, events, feedback) and start empty again?')) return;
    clearAll();
    clearState();
  };

  const doPass = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPass.length < 6) { alert('Password must be at least 6 characters.'); return; }
    changeAdminPass(newPass);
    setNewPass('');
    setShowPass(false);
    alert('Admin password updated.');
  };

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="seal"><img src="/palo-seal.png" alt="Municipality of Palo seal" onError={(e) => { e.currentTarget.src = '/palo-seal.svg'; }} /></div>
          <div>
            <h1>LGU Palo, Leyte<br />AI Budget Monitor</h1>
            <p>Tech-Voc · Health · Mayor's Office</p>
          </div>
        </div>
        <div className="row">
          <span className={`pill ${isAdmin ? 'vio' : 'info'}`}>{isAdmin ? '🔐 Admin' : '👁️ Viewer'}</span>
          <span style={{ fontSize: 12, color: '#cbd5e1' }}>{auth.name}</span>
        </div>
        <nav className="nav">
          {TABS.map((t) => (
            <button key={t.id} className={safeTab === t.id ? 'active' : ''} onClick={() => setTab(t.id)}>
              {t.label}
              {t.id === 'feedback' && isAdmin && newFb > 0 && <span className="count-badge">{newFb}</span>}
            </button>
          ))}
        </nav>
        <div className="side-foot">
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <span>Logged in as <strong>{auth.name}</strong></span>
            <button className="btn small ghost" onClick={logout}>Log out</button>
          </div>
          {isAdmin ? (
            <div style={{ marginTop: 8, display: 'grid', gap: 6 }}>
              {!showPass ? (
                <button className="btn small dark" onClick={() => setShowPass(true)}>Change admin password</button>
              ) : (
                <form onSubmit={doPass} className="row">
                  <input type="password" value={newPass} onChange={(e) => setNewPass(e.target.value)} placeholder="New password (min 6)" style={{ flex: 1 }} />
                  <button className="btn small primary" type="submit">Save</button>
                </form>
              )}
              <button className="btn small danger" onClick={doClear}>Clear all data</button>
              <span>All records are stored in the system database (this browser).</span>
            </div>
          ) : (
            <div style={{ marginTop: 8 }}>Dashboard view only. Check the Events tab for upcoming activities, and use Feedback to send comments or concerns.</div>
          )}
        </div>
      </aside>
      <main className="main">
        <div className="mobile-nav">
          {TABS.map((t) => (
            <button key={t.id} className={safeTab === t.id ? 'active' : ''} onClick={() => setTab(t.id)}>{t.label}</button>
          ))}
          <button onClick={logout}>⏻ Logout ({auth.name})</button>
        </div>
        <div className="topbar">
          <div>
            <h2>{active.label}</h2>
            <p>{active.desc} · Municipality of Palo, Leyte · FY {state.fiscalYear}</p>
          </div>
          <div className="row no-print">
            <span className={`pill ${isAdmin ? 'vio' : 'info'}`}>{isAdmin ? '🔐 Admin — full control' : '👁️ Viewer — dashboard only'}</span>
            <span className={`pill ${connected ? 'ok' : 'warn'}`} title={connected ? 'Connected to shared server — admin receives viewer feedback across devices' : 'Shared server not reachable — data stays in this browser only. Run: npm run server'}>
              {connected ? '● Shared server connected' : '● This browser only'}
            </span>
          </div>
        </div>
        {safeTab === 'dashboard' && <Dashboard go={setTab} />}
        {safeTab === 'events' && <EventsSection />}
        {safeTab === 'bank' && isAdmin && <BankVerification />}
        {safeTab === 'budget' && isAdmin && <BudgetPlanner />}
        {safeTab === 'vendors' && isAdmin && <VendorManager />}
        {safeTab === 'vouchers' && isAdmin && <VoucherGenerator />}
        {safeTab === 'reports' && isAdmin && <Reports />}
        {safeTab === 'forecast' && isAdmin && <ForecastPanel />}
        {safeTab === 'feedback' && <FeedbackSection />}
        <p style={{ fontSize: 11, color: '#64748b', marginTop: 16 }}>
          Built for LGU Palo, Leyte — Technical Vocational School, Municipal Health Office & Mayor's Office ·
          Forecasting: OLS trend + weighted moving average + seasonal index · For demo/educational use; validate with MTO & COA rules before official use.
        </p>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
