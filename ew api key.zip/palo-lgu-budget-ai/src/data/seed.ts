// Pre-loaded demo data removed.
//
// The system now starts EMPTY: the admin encodes all bank accounts,
// budgets, businesses/vendors, vouchers and billings through the UI,
// and every record is stored in the database (see src/lib/db.ts).
//
// This file is kept only as a typed stub so older imports keep working.

import type { ActivityProject, BankAccount, Billing, Vendor, Voucher } from '../types';

export const seedVendors: Vendor[] = [];
export const seedAccounts: BankAccount[] = [];
export const seedActivities: ActivityProject[] = [];
export const seedVouchers: Voucher[] = [];
export const seedBillings: Billing[] = [];
