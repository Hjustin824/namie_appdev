// Vendor Forecasting Algorithm
// Hybrid model: Linear Trend (OLS regression) + Weighted Moving Average + Seasonal Index
// Designed to be explainable for LGU audit purposes (no black box).

import type { Billing } from '../types';

export interface MonthlyPoint {
  year: number;
  month: number; // 1-12
  label: string;
  actual: number | null;
  forecast: number | null;
}

export interface VendorForecast {
  vendorId: string;
  historyMonths: number;
  avgMonthly: number;
  trendSlope: number; // pesos per month
  trendDirection: 'Rising' | 'Falling' | 'Stable';
  seasonalPeakMonth: number;
  seasonalIndex: number[];
  next3Months: { year: number; month: number; amount: number }[];
  next12Months: { year: number; month: number; amount: number }[];
  annualForecast: number;
  confidence: number; // 0-100
  volatility: number; // coefficient of variation 0-1
  riskLevel: 'Low' | 'Medium' | 'High';
  recommendation: string;
  explanation: string;
  // --- Added detail fields (backward-compatible) ---
  r2: number; // OLS goodness-of-fit 0-1
  mape: number; // in-sample mean abs % error 0-100
  yoyGrowth: number | null; // % change, last 3mo vs same 3mo last year
  low12Months: { year: number; month: number; amount: number }[];
  high12Months: { year: number; month: number; amount: number }[];
}

const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function monthLabel(year: number, month: number): string {
  return `${MONTH_NAMES[month - 1]} ${year}`;
}

function mean(xs: number[]): number {
  if (xs.length === 0) return 0;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function std(xs: number[]): number {
  if (xs.length < 2) return 0;
  const m = mean(xs);
  return Math.sqrt(xs.reduce((a, b) => a + (b - m) ** 2, 0) / xs.length);
}

/** Ordinary least squares slope + intercept over sequential index */
function linearRegression(values: number[]): { slope: number; intercept: number; r2: number } {
  const n = values.length;
  if (n === 0) return { slope: 0, intercept: 0, r2: 0 };
  if (n === 1) return { slope: 0, intercept: values[0], r2: 1 };
  const xs = values.map((_, i) => i);
  const mx = mean(xs);
  const my = mean(values);
  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    num += (xs[i] - mx) * (values[i] - my);
    den += (xs[i] - mx) ** 2;
  }
  const slope = den === 0 ? 0 : num / den;
  const intercept = my - slope * mx;
  // R^2
  let ssTot = 0;
  let ssRes = 0;
  for (let i = 0; i < n; i++) {
    ssTot += (values[i] - my) ** 2;
    ssRes += (values[i] - (slope * xs[i] + intercept)) ** 2;
  }
  const r2 = ssTot === 0 ? 1 : Math.max(0, 1 - ssRes / ssTot);
  return { slope, intercept, r2 };
}

/** Average seasonal index per calendar month (value / overall mean), smoothed */
function seasonalIndices(values: number[], months: number[]): number[] {
  const overall = mean(values) || 1;
  const buckets: number[][] = Array.from({ length: 12 }, () => []);
  values.forEach((v, i) => {
    buckets[months[i] - 1].push(v / overall);
  });
  return buckets.map((b) => (b.length === 0 ? 1 : mean(b)));
}

export function getVendorMonthlySeries(billings: Billing[], vendorId: string): { year: number; month: number; total: number }[] {
  const map = new Map<string, { year: number; month: number; total: number }>();
  for (const b of billings) {
    if (b.vendorId !== vendorId) continue;
    const key = `${b.year}-${b.month}`;
    const cur = map.get(key);
    if (cur) cur.total += b.amountBilled;
    else map.set(key, { year: b.year, month: b.month, total: b.amountBilled });
  }
  return [...map.values()].sort((a, b) => a.year - b.year || a.month - b.month);
}

export function forecastVendor(billings: Billing[], vendorId: string, horizon = 12): VendorForecast {
  const series = getVendorMonthlySeries(billings, vendorId);
  const values = series.map((s) => s.total);
  const months = series.map((s) => s.month);

  if (values.length === 0) {
    return {
      vendorId, historyMonths: 0, avgMonthly: 0, trendSlope: 0, trendDirection: 'Stable',
      seasonalPeakMonth: 1, seasonalIndex: Array(12).fill(1),
      next3Months: [], next12Months: [], annualForecast: 0,
      confidence: 0, volatility: 0, riskLevel: 'High',
      recommendation: 'No billing history — require 3+ months of transactions before forecasting.',
      explanation: 'Insufficient data.',
      r2: 0, mape: 0, yoyGrowth: null, low12Months: [], high12Months: [],
    };
  }

  const avg = mean(values);
  const sd = std(values);
  const volatility = avg === 0 ? 0 : sd / avg;
  const { slope, intercept, r2 } = linearRegression(values);
  const seasonal = seasonalIndices(values, months);

  // Weighted moving average (last 3, weights 0.5/0.3/0.2)
  const last3 = values.slice(-3);
  const w = [0.2, 0.3, 0.5].slice(3 - last3.length);
  const wSum = w.reduce((a, b) => a + b, 0);
  const wma = last3.reduce((a, v, i) => a + v * w[i], 0) / (wSum || 1);

  // Anchor future trend at end of regression line, blended 60% regression + 40% WMA
  const n = values.length;
  const lastTrend = slope * (n - 1) + intercept;
  const base = 0.6 * Math.max(0, lastTrend) + 0.4 * wma;

  // Determine starting calendar position
  const last = series[series.length - 1];
  let y = last.year;
  let m = last.month;

  const next12Months: { year: number; month: number; amount: number }[] = [];
  for (let h = 1; h <= horizon; h++) {
    m += 1;
    if (m > 12) { m = 1; y += 1; }
    const trendComponent = base + slope * h * 0.85; // dampen trend slightly
    const seasonalFactor = seasonal[m - 1] ?? 1;
    // Blend: 70% seasonal-adjusted trend, 30% base
    const amount = Math.max(0, Math.round(0.7 * trendComponent * (0.6 + 0.4 * seasonalFactor) + 0.3 * base));
    next12Months.push({ year: y, month: m, amount });
  }

  const annualForecast = next12Months.reduce((a, b) => a + b.amount, 0);
  const trendDirection = slope > avg * 0.015 ? 'Rising' : slope < -avg * 0.015 ? 'Falling' : 'Stable';
  const seasonalPeakMonth = seasonal.indexOf(Math.max(...seasonal)) + 1;

  // Confidence: driven by history length, R^2 fit, and volatility
  const lengthScore = Math.min(1, values.length / 18);
  const fitScore = 0.35 + 0.65 * r2;
  const volScore = Math.max(0, 1 - volatility);
  const confidence = Math.round(100 * (0.4 * lengthScore + 0.35 * fitScore + 0.25 * volScore));

  const riskLevel: VendorForecast['riskLevel'] =
    volatility > 0.65 || confidence < 45 ? 'High' : volatility > 0.35 || confidence < 70 ? 'Medium' : 'Low';

  const peakName = MONTH_NAMES[seasonalPeakMonth - 1];
  const recommendation =
    trendDirection === 'Rising'
      ? `Spending with this vendor is rising (+₱${Math.round(slope).toLocaleString()}/mo). Reserve ₱${Math.round(annualForecast / 12).toLocaleString()}/mo for FY budget and consider a framework agreement to lock prices.`
      : trendDirection === 'Falling'
        ? `Spending is declining. Maintain a leaner allocation of ₱${Math.round(annualForecast / 12).toLocaleString()}/mo and reallocate savings to ${peakName} peak needs.`
        : `Spending is stable at ~₱${Math.round(avg).toLocaleString()}/mo. Budget ₱${Math.round(annualForecast).toLocaleString()} for next 12 months.`;

  const explanation = `OLS trend ₱${Math.round(slope).toLocaleString()}/mo (R²=${r2.toFixed(2)}), 3-mo weighted average ₱${Math.round(wma).toLocaleString()}, seasonal peak ${peakName} (×${seasonal[seasonalPeakMonth - 1].toFixed(2)}), volatility ${(volatility * 100).toFixed(1)}% over ${values.length} months.`;

  // --- Added details ---
  // In-sample MAPE of the OLS trend line vs actuals (explainable accuracy).
  let apeSum = 0;
  for (let i = 0; i < n; i++) {
    const fitted = slope * i + intercept;
    apeSum += Math.abs(values[i] - fitted) / Math.max(1, values[i]);
  }
  const mape = n === 0 ? 0 : Math.round((apeSum / n) * 1000) / 10;

  // Scenario bands from volatility (conservative / aggressive).
  const width = Math.min(0.6, Math.max(0.05, volatility) * 0.9);
  const low12Months = next12Months.map((p) => ({ ...p, amount: Math.max(0, Math.round(p.amount * (1 - width))) }));
  const high12Months = next12Months.map((p) => ({ ...p, amount: Math.round(p.amount * (1 + width)) }));

  // YoY: last 3 months vs same 3 months a year ago (null when unavailable).
  let yoyGrowth: number | null = null;
  if (series.length >= 4) {
    const byKey = new Map(series.map((s) => [`${s.year}-${s.month}`, s.total]));
    const recent = series.slice(-3);
    const prior = recent.map((s) => byKey.get(`${s.year - 1}-${s.month}`));
    if (prior.every((v) => v !== undefined && v > 0)) {
      const rAvg = mean(recent.map((s) => s.total));
      const pAvg = mean((prior as number[]).map(Number));
      if (pAvg > 0) yoyGrowth = Math.round(((rAvg - pAvg) / pAvg) * 1000) / 10;
    }
  }

  return {
    vendorId,
    historyMonths: values.length,
    avgMonthly: Math.round(avg),
    trendSlope: Math.round(slope),
    trendDirection,
    seasonalPeakMonth,
    seasonalIndex: seasonal,
    next3Months: next12Months.slice(0, 3),
    next12Months,
    annualForecast: Math.round(annualForecast),
    confidence,
    volatility: Math.round(volatility * 1000) / 1000,
    riskLevel,
    recommendation,
    explanation,
    r2: Math.round(r2 * 1000) / 1000,
    mape,
    yoyGrowth,
    low12Months,
    high12Months,
  };
}

/** Office-level aggregate forecast = sum of vendor forecasts for billings in that office */
export function forecastOfficeAnnual(billings: Billing[], office: string): number {
  const vendorIds = [...new Set(billings.filter((b) => b.office === office).map((b) => b.vendorId))];
  return vendorIds.reduce((sum, id) => sum + forecastVendor(billings, id).annualForecast * officeShare(billings, id, office), 0);
}

function officeShare(billings: Billing[], vendorId: string, office: string): number {
  const tot = billings.filter((b) => b.vendorId === vendorId).reduce((a, b) => a + b.amountBilled, 0) || 1;
  const off = billings.filter((b) => b.vendorId === vendorId && b.office === office).reduce((a, b) => a + b.amountBilled, 0);
  return off / tot;
}
