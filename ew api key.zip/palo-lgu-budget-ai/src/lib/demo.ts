// One-click demo dataset so the AI forecast works instantly.
// Deterministic (seeded) — same figures every time, clearly labeled as demo.
// Admin can delete everything again with "Clear all data".

import type { Billing, OfficeCode, Vendor } from '../types';
import { uid } from './utils';

function mulberry(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const MONTHS_BACK = 18;

function monthCursor(back: number): { year: number; month: number } {
  const d = new Date();
  d.setDate(1);
  d.setMonth(d.getMonth() - back);
  return { year: d.getFullYear(), month: d.getMonth() + 1 };
}

export interface DemoData {
  vendors: Vendor[];
  billings: Billing[];
}

export function buildDemoData(): DemoData {
  const rand = mulberry(20260214);
  const vendors: Vendor[] = [
    {
      id: uid('v'), name: 'Palo Medical Supplies Trading', category: 'Medical Supplies',
      contactPerson: 'Demo Contact', phone: '0917-000-0001', email: '', address: 'Palo, Leyte',
      tin: 'DEMO-0001', rating: 4, active: true, preferredOffices: ['MHO'],
    },
    {
      id: uid('v'), name: 'Leyte Builders & Hardware', category: 'Construction',
      contactPerson: 'Demo Contact', phone: '0917-000-0002', email: '', address: 'Palo, Leyte',
      tin: 'DEMO-0002', rating: 5, active: true, preferredOffices: ['MAYOR'],
    },
    {
      id: uid('v'), name: 'Fiesta Catering Services', category: 'Catering',
      contactPerson: 'Demo Contact', phone: '0917-000-0003', email: '', address: 'Palo, Leyte',
      tin: 'DEMO-0003', rating: 4, active: true, preferredOffices: ['TVS', 'MAYOR'],
    },
    {
      id: uid('v'), name: 'Office Essentials Trading', category: 'Office Supplies',
      contactPerson: 'Demo Contact', phone: '0917-000-0004', email: '', address: 'Tacloban City',
      tin: 'DEMO-0004', rating: 3, active: true, preferredOffices: ['TVS', 'MHO', 'MAYOR'],
    },
  ];

  // Distinct spend personalities so trend/seasonality/risk are all visible.
  const profiles = [
    { base: 85000, slope: 2200, peak: 12, peakBoost: 0.55, noise: 0.1, office: 'MHO' as OfficeCode },
    { base: 140000, slope: -1500, peak: 6, peakBoost: 0.4, noise: 0.18, office: 'MAYOR' as OfficeCode },
    { base: 60000, slope: 3500, peak: 5, peakBoost: 0.9, noise: 0.22, office: 'TVS' as OfficeCode },
    { base: 35000, slope: 300, peak: 1, peakBoost: 0.25, noise: 0.08, office: 'MHO' as OfficeCode },
  ];

  const billings: Billing[] = [];
  vendors.forEach((v, vi) => {
    const p = profiles[vi];
    for (let back = MONTHS_BACK - 1; back >= 0; back--) {
      const { year, month } = monthCursor(back);
      const age = MONTHS_BACK - 1 - back; // 0 = oldest
      const seasonal = month === p.peak ? 1 + p.peakBoost : 1;
      const jitter = 1 + (rand() - 0.5) * 2 * p.noise;
      const billed = Math.max(5000, Math.round((p.base + p.slope * age) * seasonal * jitter));
      const paid = Math.round(billed * (0.6 + rand() * 0.4));
      billings.push({
        id: uid('b'),
        vendorId: v.id,
        office: p.office,
        activityId: '',
        year,
        month,
        amountBilled: billed,
        amountPaid: paid,
        dueDate: `${year}-${String(month).padStart(2, '0')}-28`,
        status: paid >= billed ? 'Paid' : paid > 0 ? 'Partial' : 'Billed',
        orNo: `DEMO-${year}${String(month).padStart(2, '0')}`,
      });
    }
  });

  return { vendors, billings };
}
