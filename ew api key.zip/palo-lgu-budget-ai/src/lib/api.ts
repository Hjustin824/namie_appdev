// Client for the shared backend (server.mjs).
// All functions return null on failure (server not running) so callers can
// fall back to browser localStorage and keep working offline / single-device.

import type { AppState, Feedback } from '../types';

async function req(path: string, init?: RequestInit, timeoutMs = 4000): Promise<Response | null> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    const res = await fetch(path, { ...init, signal: ctrl.signal });
    clearTimeout(t);
    return res;
  } catch {
    return null;
  }
}

export async function serverUp(): Promise<boolean> {
  const res = await req('/api/health', undefined, 2000);
  return !!res && res.ok;
}

export async function getServerState(): Promise<AppState | null> {
  const res = await req('/api/state');
  if (!res || !res.ok) return null;
  try {
    return (await res.json()) as AppState;
  } catch {
    return null;
  }
}

export async function putServerState(state: AppState): Promise<AppState | null> {
  const res = await req('/api/state', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(state),
  });
  if (!res || !res.ok) return null;
  try {
    return (await res.json()) as AppState;
  } catch {
    return null;
  }
}

export async function postFeedback(fb: Feedback): Promise<boolean> {
  const res = await req('/api/feedbacks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(fb),
  });
  return !!res && (res.ok || res.status === 201);
}

export async function patchFeedback(id: string, patch: { status?: string; response?: string }): Promise<boolean> {
  const res = await req(`/api/feedbacks/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(patch),
  });
  return !!res && res.ok;
}

export async function deleteFeedback(id: string): Promise<boolean> {
  const res = await req(`/api/feedbacks/${encodeURIComponent(id)}`, { method: 'DELETE' });
  return !!res && res.ok;
}
