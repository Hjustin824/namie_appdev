import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import type { AppState } from '../types';
import {
  clearSession,
  emptyState,
  FEEDBACK_STORAGE_KEY,
  getAdminPass,
  loadSession,
  loadState,
  saveSession,
  saveState,
  setAdminPass,
  type Session,
} from './db';
import { getServerState, putServerState, serverUp } from './api';

export { DEFAULT_ADMIN_PASS, DEFAULT_ADMIN_USER } from './db';

interface Store {
  state: AppState;
  setState: (fn: (s: AppState) => AppState) => void;
  refresh: () => void;
  clearAll: () => void;
  connected: boolean;
  auth: Session;
  isAdmin: boolean;
  loginAdmin: (password: string) => boolean;
  loginViewer: (name: string) => void;
  logout: () => void;
  changeAdminPass: (next: string) => void;
}

const Ctx = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, set] = useState<AppState>(loadState);
  const [auth, setAuth] = useState<Session>(loadSession);
  const [connected, setConnected] = useState(false);
  const lastSent = useRef<string>('');

  // Persist locally + push to shared server (debounced by change).
  // Local save always runs so the app still works with no server.
  useEffect(() => {
    saveState(state);
    const json = JSON.stringify(state);
    if (json === lastSent.current) return;
    lastSent.current = json;
    void putServerState(state).then((res) => {
      setConnected(res !== null);
    });
  }, [state]);

  useEffect(() => {
    if (auth.role) saveSession(auth);
  }, [auth]);

  const setState = (fn: (s: AppState) => AppState) => set((s) => fn(s));
  const clearAll = () => set(emptyState());
  const refresh = () => {
    void (async () => {
      const srv = await getServerState();
      if (srv) {
        setConnected(true);
        set((prev) => (JSON.stringify(prev) === JSON.stringify(srv) ? prev : { ...emptyState(), ...srv, events: Array.isArray(srv.events) ? srv.events : [] }));
      } else {
        set(loadState());
      }
    })();
  };

  // Initial pull + live poll of the shared server so the admin inbox
  // receives viewer feedback sent from other phones/PCs.
  useEffect(() => {
    let stop = false;
    const pull = async () => {
      const srv = await getServerState();
      if (stop) return;
      if (!srv) {
        setConnected(false);
        return;
      }
      setConnected(true);
      const srvJson = JSON.stringify(srv);
      set((prev) => {
        if (JSON.stringify(prev) === srvJson) return prev;
        // Union feedbacks: keep locally-created messages not yet on the
        // server so an offline submit is never wiped by a poll.
        const byId = new Map<string, (typeof srv.feedbacks)[number]>();
        for (const f of srv.feedbacks) byId.set(f.id, f);
        for (const f of prev.feedbacks) if (!byId.has(f.id)) byId.set(f.id, f);
        const merged: AppState = {
          ...srv,
          events: Array.isArray(srv.events) ? srv.events : [],
          feedbacks: [...byId.values()].sort((a, b) =>
            String(b.createdAt || '').localeCompare(String(a.createdAt || ''))
          ),
        };
        if (JSON.stringify(prev) === JSON.stringify(merged)) return prev;
        // Push merged result back so the server converges too.
        lastSent.current = JSON.stringify(merged);
        void putServerState(merged);
        return merged;
      });
    };
    void serverUp().then((ok) => {
      if (!stop) setConnected(ok);
    });
    void pull();
    const id = setInterval(pull, 4000);
    const onFocus = () => void pull();
    window.addEventListener('focus', onFocus);
    return () => {
      stop = true;
      clearInterval(id);
      window.removeEventListener('focus', onFocus);
    };
  }, []);

  // Cross-tab sync: if a viewer submits feedback in another tab on the same
  // browser/device, the admin tab picks it up automatically. Without this,
  // state is loaded once on mount and the admin inbox stays stale/empty.
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === FEEDBACK_STORAGE_KEY) set(loadState());
    };
    const onFocus = () => set(loadState());
    window.addEventListener('storage', onStorage);
    window.addEventListener('focus', onFocus);
    return () => {
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('focus', onFocus);
    };
  }, []);

  const loginAdmin = (password: string): boolean => {
    if (password === getAdminPass()) {
      setAuth({ role: 'admin', name: 'Administrator' });
      return true;
    }
    return false;
  };

  const loginViewer = (name: string) => {
    setAuth({ role: 'viewer', name: name.trim() || 'Guest Viewer' });
  };

  const logout = () => {
    setAuth({ role: null, name: '' });
    clearSession();
  };

  const changeAdminPass = (next: string) => setAdminPass(next);

  return (
    <Ctx.Provider
      value={{ state, setState, refresh, clearAll, connected, auth, isAdmin: auth.role === 'admin', loginAdmin, loginViewer, logout, changeAdminPass }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useStore(): Store {
  const v = useContext(Ctx);
  if (!v) throw new Error('useStore must be used inside StoreProvider');
  return v;
}
