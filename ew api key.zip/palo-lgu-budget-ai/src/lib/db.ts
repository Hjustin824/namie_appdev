// Database layer for the LGU Palo Budget Monitoring System.
//
// The app is currently frontend-only, so this module persists all records
// (bank accounts, budgets, vendors, vouchers, billings, feedback) plus the
// login session and admin credentials in the browser's localStorage, which
// acts as the system database. Every create/edit/delete in the UI flows
// through here, so all admin-entered data is stored and automatically
// reflected across every section.
//
// To move to a server database later (e.g. Supabase/Firebase/MySQL API),
// only the functions in this file need to be replaced — the rest of the
// app code stays unchanged.

import type { AppState, Role } from '../types';

const DATA_KEY = 'palo-lgu-budget-ai-v2'; // v2: starts empty, no pre-loaded figures
export const FEEDBACK_STORAGE_KEY = DATA_KEY;
const SESSION_KEY = 'palo-lgu-session-v1';
const PASS_KEY = 'palo-lgu-adminpass-v1';

export const DEFAULT_ADMIN_USER = 'admin';
export const DEFAULT_ADMIN_PASS = 'admin123';

export interface Session {
  role: Role | null;
  name: string;
}

/** Fresh empty database — no fixed numbers or business data. */
export function emptyState(): AppState {
  return {
    accounts: [],
    activities: [],
    vendors: [],
    vouchers: [],
    billings: [],
    feedbacks: [],
    events: [],
    fiscalYear: new Date().getFullYear(),
  };
}

function isValidState(p: unknown): p is AppState {
  if (!p || typeof p !== 'object') return false;
  const s = p as Record<string, unknown>;
  return (
    Array.isArray(s.accounts) &&
    Array.isArray(s.activities) &&
    Array.isArray(s.vendors) &&
    Array.isArray(s.vouchers) &&
    Array.isArray(s.billings)
  );
}

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(DATA_KEY);
    if (!raw) return emptyState();
    const parsed: unknown = JSON.parse(raw);
    if (!isValidState(parsed)) return emptyState();
    // Forward-compatible merge so older saves still load after upgrades.
    const rec = parsed as unknown as Record<string, unknown>;
    return { ...emptyState(), ...parsed, feedbacks: Array.isArray(parsed.feedbacks) ? parsed.feedbacks : [], events: Array.isArray(rec.events) ? (rec.events as AppState['events']) : [] };
  } catch {
    return emptyState();
  }
}

export function saveState(state: AppState): void {
  try {
    localStorage.setItem(DATA_KEY, JSON.stringify(state));
  } catch {
    /* storage full — ignore */
  }
}

export function clearState(): void {
  try {
    localStorage.removeItem(DATA_KEY);
  } catch {
    /* ignore */
  }
}

export function loadSession(): Session {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return { role: null, name: '' };
    const parsed = JSON.parse(raw) as Session;
    if (parsed.role !== 'admin' && parsed.role !== 'viewer') return { role: null, name: '' };
    return { role: parsed.role, name: String(parsed.name ?? '') };
  } catch {
    return { role: null, name: '' };
  }
}

export function saveSession(s: Session): void {
  try {
    localStorage.setItem(SESSION_KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

export function clearSession(): void {
  try {
    localStorage.removeItem(SESSION_KEY);
  } catch {
    /* ignore */
  }
}

export function getAdminPass(): string {
  try {
    return localStorage.getItem(PASS_KEY) || DEFAULT_ADMIN_PASS;
  } catch {
    return DEFAULT_ADMIN_PASS;
  }
}

export function setAdminPass(p: string): void {
  try {
    localStorage.setItem(PASS_KEY, p);
  } catch {
    /* ignore */
  }
}
